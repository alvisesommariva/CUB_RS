
function demo_driver(example)

% DEMO ILLUSTRATING ONE BY ONE THE NUMERICAL EXPERIMENTS.

if nargin < 1, example = 6; end



switch example

    case 1
        % CUBATURE S(3), S(4), S(5) (TABLE II).
        domain_typeV=1:3;
        adeV=2:2:10;
        for k=1:length(domain_typeV)
            domain_type=domain_typeV(k);
            fprintf('\n \t ................... DOMAIN %3.0f ..................',...
                domain_type);
            demo_nurbs_test_01(domain_type);
        end


    case 2
        % COMPARISON WITH PREVIOUS PAPER (TABLE I).
        domain_typeV=[2 4];
        adeV=2:2:10;
        for k=1:length(domain_typeV)
            domain_type=domain_typeV(k);
            for j=1:length(adeV)
                [card_Z(k,j),card_Zin(k,j),card_nodes(k,j),condcub(k,j),...
                    monbasRE(k,j),cpusM]=demo_nurbs_test_02...
                    (domain_type,adeV(j));
                cpus_2021(k,j)=cpusM(1);
                cpus_2019(k,j)=cpusM(2);
            end
        end

        for k=1:length(domain_typeV)
            fprintf('\n \t ............ DOMAIN %3.0f ............ ',...
                domain_typeV(k));
            for j=1:length(adeV)
                fprintf('\n \t |%2.0f|%3.0f|%4.0f|%4.0f|%1.3e|%1.0e|%1.1e|%1.1e|',...
                    adeV(j),card_nodes(k,j),card_Zin(k,j),card_Z(k,j),...
                    condcub(k,j),monbasRE(k,j),cpus_2021(k,j),...
                    cpus_2019(k,j));
            end
        end


    case 3
        % MAKE PLOTS ERRORS RAND POLYNOMIALS (FIGURE 6).
        domain_typeV=1:3;
        for k=1:length(domain_typeV)
            domain_type=domain_typeV(k);
            demo_nurbs_test_03(domain_type);
            fprintf('\n \t * PAUSE'); pause(1);
        end


    case 4
        % APPROXIMATION OF THE INTEGRALS I(f1), I(f2), I(f3) (TABLE 3)
        domain_typeV=1:3;
        for k=1:length(domain_typeV)
            domain_type=domain_typeV(k);
            demo_nurbs_test_04(domain_type);
            fprintf('\n \t * PAUSE'); pause(1);
        end


    case 5
        % CPUTIMES OF INDOMAIN ROUTINE. TABLE 4.
        domain_typeV=1:3;
        NptsV=10.^(2:6);

        % making experiment
        for k=1:length(domain_typeV)
            domain_type=domain_typeV(k);
            for j=1:length(NptsV)
                [cpus(k,j),cpus0(k,j)]=demo_nurbs_test_05(domain_type,...
                    NptsV(j));
            end
        end

        % statistics
        for k=1:length(domain_typeV)
            domain_type=domain_typeV(k);
            fprintf('\n \t ............ DOMAIN %3.0f ............ ',...
                domain_typeV(k));
            for j=1:length(NptsV)
                fprintf('\n \t | %1.0e | %1.1e | %1.1e |',...
                    NptsV(j),cpus(k,j),cpus0(k,j));
            end
        end


    case 6

        domain_typeV=1:3;
        NptsV=10.^(2:5);
        for j=domain_typeV
            for k=NptsV
                demo_nurbs_test_B01(j,k);
            end
        end


end



fprintf('\n');