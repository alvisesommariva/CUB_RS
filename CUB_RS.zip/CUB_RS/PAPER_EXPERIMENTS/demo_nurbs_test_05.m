
function [cpus1,cpus0]=demo_nurbs_test_05(domain_type,Npts)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating INDOMAIN:
% 1. how to define a NURBS on a composite boundary, using arcs of disks,
%    ellipses, segments, polygons and "free NURBS". The routines work on
%    piecewise NURBS of different order (see "define_domain" at line 206).
% 2. how too define a grid that is defined in the bounding box of the
%    domain, by "ptsRS".
% 3. how to get an indomain test on the desired domain, via
%    "inRS" routine.
% 4. plot the boundary of the domain.
%
% Note: In the numerical experiments of the accompanying paper, we have
%       used
%       1. S(3): M domain, choose domain_type=1,
%       2. S(4): joining arcs of a disk, ellipse, segment, domain_type=2,
%       3. S(5): concave domain, domain_type=3.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% domain_type: scalar that refers to a domain of integration (see routine
%              "define_domain" attached below);
% card        : scalar that refers to the algebraic degree of exactness.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
%  cpus1,cpus0: median cputimes of the indomain routine, in the "safe" and
%      "fast" version, respectively.
%--------------------------------------------------------------------------
% Reference paper:
%--------------------------------------------------------------------------
% A. Sommariva and M. Vianello,
% ﻿Low cardinality Positive Interior quadrature on NURBS-shaped domains.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: December 13, 2021 (15:41)
%--------------------------------------------------------------------------

% ------------------------------ Settings ---------------------------------

% Nbox is a technical parameter for indomain routine; in doubt set 100.
Nbox=100;

% In indomain routine one must be certain that points are inside the
% domain. In our cubature needs we just wants some points in the domain.
% Consequently, if we are not fully sure that a point is in the domain, due
% to geometrical issues, we do not take it into account.
safe_mode=1;

% Number of pointset points in the bounding box of the domain.
%
% * pts_type='rand' then "Npts" it is the number of random points.
% * pts_type='grid' then "Npts" it is the number of points for each
%                   direction then the number of points is "Npts^2".


if nargin < 2
    pts_type='rand';  Npts=10^5;
    % pts_type='halton';  Npts=10^5;
    % pts_type='grid'; Npts=floor(sqrt(10^5))
else
    pts_type='rand';
end

% Number of tests to determine the median cputime. We suggest to set
% "tests=10", while we do not recommend "tests=1" because it often turns
% out to provide unreliable cputimes.
% We remind that cputime may vary with the computer.
M=floor(log10(Npts));
switch M
    case 1
        tests=100;
    case 2
        tests=50;
    case 3
        tests=35;
    case 4
        tests=20;
    otherwise
        tests=15;
end


% Note: In the numerical experiments of the accompanying paper, we have
%       used
%       1. S(3): M domain, choose domain_type=1,
%       2. S(4): joining arcs of a disk, ellipse, segment, domain_type=2,
%       3. S(5): concave domain, domain_type=3.

if nargin < 1, domain_type=1; end

% do_plot: 1 makes plots, otherwise no plot is drawn.
do_plot=0;





% ----------------------------- Main code ---------------------------------

%--------------------------------------------------------------------------
% 1. Make NURBS structure
%--------------------------------------------------------------------------
[geometry_NURBS,domain_str]=define_domain(domain_type);

%--------------------------------------------------------------------------
% 2. Generate test points (tensorial grid on a rectangle containing domain)
%--------------------------------------------------------------------------
pts=ptsRS(geometry_NURBS,Npts,[],pts_type);

%--------------------------------------------------------------------------
% 3. Indomain (several cputime tests!).
%--------------------------------------------------------------------------
fprintf('\n \t ');
for k=1:tests
    tic;
    [in,on,SxNV,SxDV,SyNV,SyDV,boxVxy,turn_pts_X,turn_pts_Y]=inRS(...
        pts,geometry_NURBS,Nbox,1);
    cpus(k)=toc;
end

for k=1:tests
    tic;
    [in1,on1]=inRS(pts,geometry_NURBS,Nbox,0);
    cpus0(k)=toc;
end

idoubts=find(on == -Inf);
ion=find(on <= 10^(-13));
iNaN=isnan(on);


%--------------------------------------------------------------------------
% 4. Plot domain and control points polygon.
%--------------------------------------------------------------------------

if do_plot
    h=figure(1);
    f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
    if f1,clf(1);end
    figure(1)
    hold on;
    axis equal;

    % A. plot NURBS curve (black)
    plotNURBSPL(geometry_NURBS);

    % B. plot test points strictly inside and not strictly inside.

    iok=find(in == 1 & iNaN);

    plot(pts(iok,1),pts(iok,2),'g.','MarkerEdgeColor','g',...
        'MarkerFaceColor','g','MarkerSize',20);

    iko=find(not(in == 1));
    plot(pts(iko,1),pts(iko,2),'r.','MarkerEdgeColor','r',...
        'MarkerFaceColor','r','MarkerSize',20);

    plot(pts(idoubts,1),pts(idoubts,2),'c.','MarkerEdgeColor','k',...
        'MarkerFaceColor','c','MarkerSize',20);

    plot(pts(ion,1),pts(ion,2),'y.','MarkerEdgeColor','y',...
        'MarkerFaceColor','y','MarkerSize',20);

    % C. plot turning points
    if not(isempty(turn_pts_X))
        plot(turn_pts_X(:,1),turn_pts_X(:,2),'bd',...
            'MarkerEdgeColor','b',...
            'MarkerFaceColor','b',...
            'MarkerSize',10);
    end

    if not(isempty(turn_pts_Y))
        plot(turn_pts_Y(:,1),turn_pts_Y(:,2),'md',...
            'MarkerEdgeColor','m',...
            'MarkerFaceColor','m',...
            'MarkerSize',10);
    end

    % D. plot control points (red)
    P=[];
    for kk=1:length(geometry_NURBS)
        geoL=geometry_NURBS(kk); PL=geoL.P; P=[P; PL];
    end

    %     plot(P(:,1),P(:,2),'cs',...
    %         'MarkerEdgeColor','k',...
    %         'MarkerFaceColor','c',...
    %         'MarkerSize',10);
    %
    %     % E. plot control polygon (red)
    %     plot(P(:,1),P(:,2),'k:','LineWidth',2);

    % Title
    titlesrt=strcat('Indomain test:  ',num2str(size(pts,1)), ' points');
    title(titlesrt);

    hold off;





    h=figure(2);
    f2=ishandle(h)&&strcmp(get(h,'type'),'figure');
    if f2,clf(2);end
    figure(2)
    hold on;
    axis equal;


    % A. plot SPLINE curve (black)
    plotNURBSPL(geometry_NURBS);

    % B. Plot monotone boxes
    LB=size(boxVxy,1);
    for k=1:LB
        a=boxVxy(k,1); b=boxVxy(k,2); c=boxVxy(k,3); d=boxVxy(k,4);
        plot([a b b a a],[c c d d c],'c-','LineWidth',3);
    end

    % C. plot turning points

    if not(isempty(turn_pts_X))

        plot(turn_pts_X(:,1),turn_pts_X(:,2),'bd',...
            'MarkerEdgeColor','b',...
            'MarkerFaceColor','b',...
            'MarkerSize',10);

    end

    if not(isempty(turn_pts_Y))
        plot(turn_pts_Y(:,1),turn_pts_Y(:,2),'md',...
            'MarkerEdgeColor','m',...
            'MarkerFaceColor','m',...
            'MarkerSize',10);
    end


    % plotNURBSPL(geometry_NURBS,'dynamic')

    hold off;




    %     h=figure(3);
    %     f3=ishandle(h)&&strcmp(get(h,'type'),'figure');
    %     if f3,clf(3);end
    %     figure(3)
    %     hold on;
    %     axis equal;
    %     plotNURBSPL(geometry_NURBS,'component');
    %     hold on;
    %     if isempty(turn_pts_X) == 0
    %         plot(turn_pts_X(:,3),turn_pts_X(:,1),'ko',...
    %             'MarkerEdgeColor','k',...
    %             'MarkerFaceColor','k',...
    %             'MarkerSize',10)
    %     end
    %
    %     if isempty(turn_pts_Y) == 0
    %         plot(turn_pts_Y(:,3),turn_pts_Y(:,2),'yo',...
    %             'MarkerEdgeColor','k',...
    %             'MarkerFaceColor','y',...
    %             'MarkerSize',10)
    %     end
    %     hold off;
end

%--------------------------------------------------------------------------
% 5. Display statistics.
%--------------------------------------------------------------------------

fprintf('\n \t --------------------------------------------------------');
fprintf('\n \t             NURBS INDOMAIN TESTS  ')
fprintf('\n \t --------------------------------------------------------');
fprintf('\n \t DOMAIN: '); disp(domain_str);
fprintf('\n');

fprintf('\n \t # TRIAL POINTS               : %6.0f',size(pts,1));
fprintf('\n \t # DOUBT POINTS               : %6.0f',length(idoubts));
fprintf('\n \t # ON POINTS                  : %6.0f',length(ion));
iregs=find(iNaN == 1);
fprintf('\n \t # REGULAR POINTS             : %6.0f',length(iregs));
aa=boxVxy(:,1); bb=boxVxy(:,2); cc=boxVxy(:,3); dd=boxVxy(:,4);
ivert=find(bb-aa <=10^(-13));
cardvs=length(ivert);
if cardvs  > 0
    maxheight=max(dd(ivert)-cc(ivert));
else
    maxheight=NaN;
end



fprintf('\n \t # VERTICAL BOXES (NUM)       : %6.0f',cardvs);
fprintf('\n \t # VERTICAL BOXES HEIGHT (NUM): %1.3e',maxheight);
cpus1=median(cpus);
fprintf('\n \t MEDIAN CPUTIME SAFE=1         : %1.3e',cpus1);
cpus0=median(cpus0);
fprintf('\n \t MEDIAN CPUTIME SAFE=0         : %1.3e  ',cpus0);
if do_plot
    fprintf('\n \t --------------------------------------------------------');
    fprintf('\n \t             TEST DESCRIPTION  ')
    fprintf('\n \t --------------------------------------------------------');
    fprintf('\n \t TRIAL POINTS  : POINTS TESTED BY INDOMAIN ROUTINE');
    fprintf('\n \t DOUBT POINTS  : POINTS OF DIFFICULT DETERMINATION');
    fprintf('\n \t ON POINTS     : POINTS NUMERICALLY ON THE BOUNDARY');
    fprintf('\n \t VERTICAL BOXES: # VERTICAL MONOTONE BOXES');
    fprintf('\n \t VERTICAL BOXES HEIGHT: MAX WIDTH VERTICAL MONOTONE BOXES');
    fprintf('\n \t REGULAR POINTS: POINTS NUMERICALLY ON THE BOUNDARY');
    fprintf('\n \t MEDIAN CPUTIME SAFE=1: MEDIAN CPUTIME FOR GETTING ALL');
    fprintf('\n \t                POINTS IN DOMAIN/BOUNDARY');
    fprintf('\n \t MEDIAN CPUTIME SAFE=0: MEDIAN CPUTIME FOR GETTING');
    fprintf('\n \t                QUICKLY MANY POINTS IN DOMAIN/BOUNDARY');
    fprintf('\n \t --------------------------------------------------------');
    fprintf('\n \t             PLOT DESCRIPTION  ')
    fprintf('\n \t --------------------------------------------------------');
    fprintf('\n \t FIGURE 1   ');
    fprintf('\n \t * Green dots: points inside the domain S.  ')
    fprintf('\n \t * Yellow dots: points close to the boundary dS  ')
    fprintf('\n \t * Red dots: points not inside the domain S.  ')
    fprintf('\n \t * Cyan squares: control points.  ')
    fprintf('\n \t * Black dotted lines: control polygon.  ')
    fprintf('\n \t * Magenta diamonds: boundary singular points.  ')
    fprintf('\n \t --------------------------------------------------------');
    fprintf('\n \t FIGURE 2   ');
    fprintf('\n \t * Cyan squares: monotone boxes (even "small")   ')
    % fprintf('\n \t * Black dotted lines: control polygon.  ')

    fprintf('\n \t * Blue diamonds: bound. sing. points X dir.  ')
    fprintf('\n \t * Magenta diamonds: bound. sing. points Y dir.   ')
    fprintf('\n \t --------------------------------------------------------');
    fprintf('\n \t NOTE:  ');
    fprintf('\n \t 1. The two figures may overlap.');
    fprintf(2,'\n \t 2. %3.0f cputime tests for each indomain routine.  \n \t',...
        tests);
    str=strcat(' 3. The points are of'," ",pts_type," ",'type.');
    disp(str);
    fprintf('\t -------------------------------------------------------- \n ');
end






%--------------------------------------------------------------------------
% ATTACHED ROUTINES
%--------------------------------------------------------------------------

function [geometry_NURBS,domain_str]=define_domain(example)

switch example

    case 1 % M-shaped domain

        domain_str='S(3): M shaped domain';
        order=3;
        P=[-1 1; -1 0; -1 -1; -0.6 -1; -0.6 0; -0.6 0.6; 0 0; 0.6 0.6; ...
            0.6 0; 0.6 -1; 1 -1; 1 0; 1 1; 0.6 1; 0 0.4; -0.6 1; -1 1];
        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 2

        domain_str='S(4): domain defined by a disk, an ellipse, a segment';
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',[0 0],'angles',[pi/2 3*pi/2],'ell_axis',[0.5 1],...
            'tilt_angle',0);

        % add a final segment
        Pend=lastpointNURBSPL(geometry_NURBS(2));
        Pinit=firstpointNURBSPL(geometry_NURBS(1));
        geometry_NURBS(3)=makeNURBSarc('segment','vertices',[Pend; Pinit]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

    case 3 % lune-like
        domain_str='S(5): lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        knots=[0 0 0 .15 .25 .25 .5 .5 .75 .75 1 1 1];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1];
        order=3;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 4 % square/disk difference
        domain_str='domain 4';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));


        % add arc of an ellipse
        v=[0.5 0;0.5 0.5;0 0.5];
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);





    case 5 % polygon/disk union
        domain_str='domain 5';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0.25 0.25],'angles',[pi pi+pi/2],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.4 0.05; 0.5 0.25; 0.45 0.45; 0.3 0.5;0.1 0.45]; % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);





    case 6 % polygon/disk union
        domain_str='domain 6';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.25 0.2; 0.2 0.25];  % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);



    case 7 % polygon/disk union
        domain_str='domain 7';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.4 0.05; 0.5 0.25; 0.45 0.45; 0.3 0.5;0.1 0.45]; % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);


    case 8 % polygon/disk union
        domain_str='domain 8: square';

        v=[0 0; 1 0; 1 1; 0 1; 0 0];
        geometry_NURBS(1)=makeNURBSarc('polygonal_arc',...
            'vertices',v);


    case 9 % polygon/disk union
        domain_str='domain 9: union of rectangles';

        % add arc of an ellipse
        v=[0 0; 1 0; 1 1; 2 1; 2 2; 1 2; 1 1.5; 0 1.5; 0 1.25; -0.5 1.25; ...
            -0.5 0; 0 0];
        geometry_NURBS(1)=makeNURBSarc('polygonal_arc',...
            'vertices',v);










    case 10
        domain_str='domain 10: square';
        P=[0 0; 1 0; 1 1; 0 1; 0 0];
        geometry_NURBS=makeNURBSarc('polygonal_arc','vertices',P);

    case 11 % circle
        domain_str='domain 11: circle';
        geometry_NURBS=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 2*pi],'radius',1);

    case 12 % lune-like
        domain_str='domain 12: lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        order=3;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free',...
            'P',P,'knots',knots,'weights',w,'order',order);


    case 13 % tau-like-symbol
        domain_str='domain 13: tau-like-symbol';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5;  ...
            0.2 -0.45; -0.4 -0.4; 0 -1; 1 -1;  1 0];
        order=3;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 14 % cubic-domain
        domain_str='domain 14: cubic-domain: leaf';
        P=[1 0; 1 1; 0 1; -1 1; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);



    case 15 % cubic-domain: nut
        domain_str='domain 15: cubic-domain: slanted nut';
        P=[1 0; 1 1; 0 1; -1 0.6; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 16 % cubic-domain: slanted boomerang
        domain_str='domain 16: cubic-domain: golf club';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.4 0.6; 0 0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c/2 1 c/4 1 c/4 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 17 % cubic-domain: nut
        domain_str='domain 17: cubic-domain: dino head';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 -1; 0 0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c/2 1 c/4 1 c/4 1 1 c 1];


        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 18 % cubic-domain: slanted boomerang
        domain_str='domain 18: cubic-domain: tadpole';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.4 0.6; 0 -0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 1 1 1 1 1 1 1 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 19 % cubic-domain: nut
        domain_str='domain 19: cubic-domain: nose';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 5 5 5 5 5 5 5 1];


        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 20 % rough-ball
        domain_str='domain 20: rough ball';
        order=3;
        sidesL=20;
        t=linspace(0,2*pi,sidesL); t=t';
        P=[cos(t) sin(t)]; P=[P(1:end-1,:); P(1,:)];
        knots_mid=linspace(0.1,0.9,sidesL-order);
        knots=[zeros(1,order) knots_mid ones(1,order)];
        M=size(P,1);
        % w=rand(1,M);
        w=[ 8.258169774895474e-01
            5.383424352600571e-01
            9.961347166268855e-01
            7.817552875318368e-02
            4.426782697754463e-01
            1.066527701805844e-01
            9.618980808550537e-01
            4.634224134067444e-03
            7.749104647115024e-01
            8.173032206534330e-01
            8.686947053635097e-01
            8.443584551091032e-02
            3.997826490988965e-01
            2.598704028506542e-01
            8.000684802243075e-01
            4.314138274635446e-01
            9.106475944295229e-01
            1.818470283028525e-01
            2.638029165219901e-01
            1.455389803847170e-01]';

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 21 % L-shaped domain

        domain_str='domain 21: L shaped domain';
        P=[-1 1; -1 -1; 1 -1; 1 -0.6; -0.6 -0.6; -0.6 1; -1 1]; % 7 points
        order=3;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        w=[0.2 5 10 10 100 5 0.2];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 22 % variable order
        domain_str='domain 22, defined by a disk, an ellipse and a segment';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],...
            'ell_axis',[1 2],'tilt_angle',0);

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(2));

        % "close" the boundary with a segment
        geometry_NURBS(3)=makeNURBSarc('segment','extrema',...
            [Pend; Pinit]);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);



    case 23 % variable order

        domain_str1='domain 23, defined by a disk, an ellipse, a segment';
        domain_str2=' and a free NURBS (variable order)';
        domain_str=strcat(domain_str1,domain_str2);

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(end));

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(end));

        % add segment
        geometry_NURBS(3)=makeNURBSarc('segment','extrema',[Pend; 0 Pend(2)]);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS);

        % "close" the boundary with a "free" NURBS.
        geometry_NURBS(4)=makeNURBSarc('free',...
            'P',[0 Pend(2); -1.9 0.3; -1.8 0.5; Pinit],...
            'knots',[0 0 0 0 1 1 1 1],'weights',[1 1 2 1],'order',4);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

    case 24 % variable order

        domain_str='domain 24, defined by a disk, an ellipse, a segment';
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',[0 0],'angles',[pi/2 3*pi/2],'ell_axis',[0.5 1],...
            'tilt_angle',0);

        % add a final segment
        Pend=lastpointNURBSPL(geometry_NURBS(2));
        Pinit=firstpointNURBSPL(geometry_NURBS(1));
        geometry_NURBS(3)=makeNURBSarc('segment','vertices',[Pend; Pinit]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);


    case 25 % cubic-domain: nut
        domain_str='domain 25: 15-inverse cubic-domain: slanted nut';
        P=[1 0; 1 1; 0 1; -1 0.6; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        P=P(:,[2 1]);
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);



    case 26 % cubic-domain: nut
        domain_str='domain 26: cross';
        P=[-0.2 -1; 0.2 -1; 0.2 -0.2; 1 -0.2; 1 0.2; 0.2 0.2; 0.2 1; ...
            -0.2 1; -0.2 0.2; -1 0.2; -1 -0.2; -0.2 -0.2; -0.2 -1];
        geometry_NURBS=makeNURBSarc('polygonal_arc','vertices',P);

end
