
function     [card_Z,card_Zin,card_nodes,condcub,momres2,cpus_2021]=...
    demo_nurbs_test_01(domain_type)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating CUBATURE:
% 1. how to define a NURBS on a composite boundary, using arcs of disks,
%    ellipses, segments, polygons and "free NURBS". The routines work on
%    piecewise NURBS of different order.
%    To this purpose see the MATLAB function "define_domain" at the
%    bottom of this demo.
% 2. how to get an algebraic cubature rule on the desired domain, via
%    "cubRS" routine.
%
% Note: In the numerical experiments of the accompanying paper, we have
%       used
%       1. S(3): M domain, choose domain_type=1,
%       2. S(4): joining arcs of a disk, ellipse, segment, domain_type=2,
%       3. S(5): concave domain, domain_type=3.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% domain_type: scalar that refers to a domain of integration (see routine
%              "define_domain" attached below);
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% card_Z : cardinality of the set of points inside the domain from which
%          the rule was extected;
% card_Zin: cardinality of the set of points inside from which the rule 
%           was extected;
% card_nodes: cardinality of the nodes of the rule;
% condcub: cubature conditioning;
% momres2: moments matching in norm 2;
% cpus_2021: median of the cputime over a certain number of tests.
%--------------------------------------------------------------------------
% Reference paper:
%--------------------------------------------------------------------------
% A. Sommariva and M. Vianello,
% ﻿Low cardinality Positive Interior cubature on NURBS-shaped domains.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: December 5, 2021.
%--------------------------------------------------------------------------

% ------------------------------ Settings ---------------------------------

% Algebraic degree of precision of the cubature rule. Suggested values are
% mild, e.g. not larger than "ade=15". Typical "ade" in the applications
% are between "3" and "5".
adeV=2:2:10;

% Number of tests to determine the median cputime. We suggest to set
% "tests=10", while we do not recommend "tests=1" because it often turns
% out to provide unreliable cputimes.
tests=50;

% Cubature extraction method: the variable "extraction_type" sets how
% Tchakaloff rule is extracted.
%      1: lsqnonneg, 2: lawsonhanson, 3: LHDM 4: \
% If not declared or equal to "[]", the default is LHDM, see
% "dCATCH: a numerical package for d-variate near G-optimal Tchakaloff
% regression via fast NNLS"
% M. Dessole, F. Marcuzzi and M. Vianello
% MDPI-Mathematics 8 (2020) - Special Issue "Numerical Methods"
extraction_type=3;

% Nbox is a technical parameter for indomain routine; in doubt set 100.
Nbox=100;

% In indomain routine one must be certain that points are inside the
% domain. In our cubature needs we just wants some points in the domain.
% Consequently, if we are not fully sure that a point is in the domain, due
% to geometrical issues, we do not take it into account.
safe_mode=0;

% The variable "domain_type" set the domain taken into account. The names
% are just given to remember something of the region.
%
% The variable "domain_type" set the domain taken into account.
%
%       1. S(3): M domain, choose domain_type=11,
%       2. S(4): joining arcs of a disk, ellipse, segment, domain_type=14,
%       3. S(5): concave domain, domain_type=1.
if nargin < 1, domain_type=1; end


% ----------------------------- Main code ---------------------------------

%--------------------------------------------------------------------------
% 1. Make NURBS structure
%--------------------------------------------------------------------------
[geometry_NURBS,domain_str]=define_domain(domain_type);

%--------------------------------------------------------------------------
% 2. Compute algebraic cubature rule of the domain (several tests!).
%--------------------------------------------------------------------------
fprintf('\n \t |  n  |  #  | in  | all  |cnd|  moms |   cpu   |');
for k=1:length(adeV)
    ade=adeV(k);
    for j=1:tests
        tic;
        [xyw,res,Z,Zin,cmom,bbox,itlevel] = cubRS(ade,geometry_NURBS,...
            extraction_type,Nbox,safe_mode);
        cpus(j)=toc;
    end
    cardV(k)=size(xyw,1);
    trialinV(k)=size(Zin,1);
    trialallV(k)=size(Z,1);
    
    ww=xyw(:,3); condV(k)=sum(abs(ww))/abs(sum(ww));
    ii=find(ww < 0); 
    if isempty(ii) == 0, fprintf('\n \t %5.0f %3.0f',length(ii),itlevel); end

    momresV(k)=res;
    cpusV(k)=median(cpus); 

    fprintf('\n \t | %2.0f  | %3.0f | %3.0f | %4.0f | %1.3g | %1.0e | %1.1e |',...
        ade,cardV(k),trialinV(k),trialallV(k),condV(k),momresV(k),cpusV(k));

end
fprintf('\n');
fprintf('\n \t Note: ');
fprintf('\n \t n: algebraic degree of precision of the rule');
fprintf('\n \t #: cardinality of the rule');
fprintf('\n \t in: trial points safely in the domain');
fprintf('\n \t all: all tested trial points for indomain');
fprintf('\n \t cnd: cub. conditioning, if "1" all the weights are > 0');
fprintf('\n \t moms: rule moments error (norm 2)');
fprintf('\n \t cpu: median cputime over'); fprintf(2,'%3.0f tests ',tests); 
fprintf('\n');





%--------------------------------------------------------------------------
% ATTACHED ROUTINES
%--------------------------------------------------------------------------

function [geometry_NURBS,domain_str]=define_domain(example)

switch example

    case 1 % M-shaped domain

        domain_str='S(3): M shaped domain';
        order=3;
        P=[-1 1; -1 0; -1 -1; -0.6 -1; -0.6 0; -0.6 0.6; 0 0; 0.6 0.6; ...
            0.6 0; 0.6 -1; 1 -1; 1 0; 1 1; 0.6 1; 0 0.4; -0.6 1; -1 1];
        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 2

        domain_str='S(4): domain defined by a disk, an ellipse, a segment';
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',[0 0],'angles',[pi/2 3*pi/2],'ell_axis',[0.5 1],...
            'tilt_angle',0);

        % add a final segment
        Pend=lastpointNURBSPL(geometry_NURBS(2));
        Pinit=firstpointNURBSPL(geometry_NURBS(1));
        geometry_NURBS(3)=makeNURBSarc('segment','vertices',[Pend; Pinit]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

    case 3 % lune-like
        domain_str='S(5): lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        knots=[0 0 0 .15 .25 .25 .5 .5 .75 .75 1 1 1];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1];
        order=3;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

end