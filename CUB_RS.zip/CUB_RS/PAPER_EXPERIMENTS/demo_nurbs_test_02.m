
function [card_Z,card_Zin,card_nodes,condcub,monbasRE,cpusM]=...
    demo_nurbs_test_02(domain_type,ade)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating CUBATURE:
% 1. how to define a NURBS on a composite boundary, using arcs of disks
%    as well as polygonal ones.
%    To this purpose see the MATLAB function "define_domain" at the
%    bottom of this demo.
% 2. how to get an algebraic cubature rule on the desired domain, via
%    "cubRS" routine.
% 3. comparisons with results obtained in
%
%   "Algebraic cubature on polygonal elements with a circular edge",
%   Comput. Math. Appl., Volume 79, Issue 7, 1 April 2020, Pages 2057-2066.
%   E. Artioli, A. Sommariva and M. Vianello
%
%  Note: for reproducing the tests in the paper accompanying this work,
%        choose:
%
%        domain_type=2 (convex domain)
%        domain_type=4 (non-convex domain)
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% domain_type: scalar that refers to a domain of integration (see routine
%              "define_domain" attached below);
% ade        : scalar that refers to the algebraic degree of exactness.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% card_Z   : cardinality of the set of points inside the domain from which
%          the rule was extected;
% card_Zin: cardinality of the set of points inside from which the rule 
%           was extected;
% card_nodes: cardinality of the nodes of the rule;
% condcub   : cubature conditioning;
% momres2   : moments matching in norm 2;
% cpus_2021 : median of the cputimes of two algorithms (i.e. 2021 vs 2019)
%            over a certain number of tests; it is an array of length 2, in 
%            which the first number is the median cputime of the new 
%            algorithm, while the second one is the old algorithm.
%--------------------------------------------------------------------------
% Reference paper:
%--------------------------------------------------------------------------
% A. Sommariva and M. Vianello,
% ﻿Low cardinality Positive Interior quadrature on NURBS-shaped domains.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: December 13, 2021.
%--------------------------------------------------------------------------

warning off;

% ------------------------------ Settings ---------------------------------

% Algebraic degree of precision of the cubature rule. Suggested values are
% mild, e.g. not larger than "ade=15". Typical "ade" in the applications
% are between "3" and "5".

if nargin< 2, ade=6; end

% Number of tests to determine the median cputime. We suggest to set
% "tests=10", while we do not recommend "tests=1" because it often turns
% out to provide unreliable cputimes.

tests=100;

% Cubature extraction method: the variable "extraction_type" sets how
% Tchakaloff rule is extracted.
%      1: lsqnonneg, 2: lawsonhanson, 3: LHDM 4: \
% If not declared or equal to "[]", the default is LHDM, see
% "dCATCH: a numerical package for d-variate near G-optimal Tchakaloff
% regression via fast NNLS"
% M. Dessole, F. Marcuzzi and M. Vianello
% MDPI-Mathematics 8 (2020) - Special Issue "Numerical Methods"

extraction_type=3;

% Nbox is a technical parameter for indomain routine; in doubt set 100.

Nbox=100;

% In indomain routine one must be certain that points are inside the
% domain. In our cubature needs we just wants some points in the domain.
% Consequently, if we are not fully sure that a point is in the domain, due
% to geometrical issues, we do not take it into account.

safe_mode=1;

% The variable "domain_type" set the domain taken into account.
if nargin < 1
    domain_type=1;
end

% Plot domain
doplot=0; % 0: no plot, 1: plot domain







% ----------------------------- Main code ---------------------------------


%--------------------------------------------------------------------------
% 1. Make NURBS structure and data for
%--------------------------------------------------------------------------
[geometry_NURBS,domain_str]=define_domain(domain_type);
[cc,r,a,b,v,conv]=define_domain_polycirc(domain_type);

%--------------------------------------------------------------------------
% 2. Compute algebraic cubature rule of the domain (several tests!).
%--------------------------------------------------------------------------
fprintf(2,'\n \t * Performing %4.0f tests   \n ',tests);

for k=1:tests
    tic;
    [xyw,res,Z,Zin,cmom,bbox,itlevel] = cubRS(ade,geometry_NURBS,...
        extraction_type,Nbox,safe_mode);
    cpus1(k)=toc;
end

cpusM(1)=median(cpus1);


for k=1:tests
    tic;
    [xywPG,xywcPG] = polygcirc_2021(ade,v,a,b,cc,r,conv,2);
    cpus2(k)=toc;
end

cpusM(2)=median(cpus2);

I1=[]; I2=[];
for k1=0:ade
    for k2=0:ade-k1
        f=@(x,y) (x.^k1).*(y.^k2);

        % 2021
        x=xyw(:,1); y=xyw(:,2); w=xyw(:,3);
        fxy=feval(f,x,y); I1(end+1)=w'*fxy;

        % 2019
        x=xywcPG(:,1); y=xywcPG(:,2); w=xywcPG(:,3);
        fxy=feval(f,x,y); I2(end+1)=w'*fxy;
    end
end









%--------------------------------------------------------------------------
% 3. Plot domain and control points polygon.
%--------------------------------------------------------------------------

if doplot

    h=figure(1);f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
    if f1,clf(1);end
    figure(1)
    hold on;
    axis off; axis equal;

    % ....................  plot control points (red) .....................
    P=[]; % NURBS control polygon.
    for k=1:length(geometry_NURBS)
        geometry_NURBSL=geometry_NURBS(k); PL=geometry_NURBSL.P; P=[P; PL];
    end

    % plot(P(:,1),P(:,2),'cs','MarkerEdgeColor','k',...
    %     'MarkerFaceColor','c','MarkerSize',10);

    % ....................  plot control polygon (red) ....................

    % plot(P(:,1),P(:,2),'k:','LineWidth',2);

    % ....................  plot NURBS curve (black) ......................
    plotNURBSPL(geometry_NURBS);

    % ........................  plot points ...............................

    plot(Z(:,1),Z(:,2),'r*','MarkerEdgeColor','r',...
        'MarkerFaceColor','r','MarkerSize',4);

    plot(Zin(:,1),Zin(:,2),'g*','MarkerEdgeColor','g',...
        'MarkerFaceColor','g','MarkerSize',4);

    plot(xyw(:,1),xyw(:,2),'mo','MarkerEdgeColor','k',...
        'MarkerFaceColor','m','MarkerSize',10);

    hold off;

end

%--------------------------------------------------------------------------
% 3. Display statistics.
%--------------------------------------------------------------------------
fprintf('\n \t -------------------------------------------');
fprintf('\n \t          NURBS CUBATURE TESTS');
fprintf('\n \t -------------------------------------------');
fprintf('\n \t DOMAIN: '); disp(domain_str);
fprintf('\n');
fprintf('\n \t ALGEBRAIC DEGREE OF PRECISION: %6.0f',ade);
% fprintf('\n \t # CONTROL POINTS             : %6.0f',size(P,1));
card_Z=size(Z,1);
fprintf('\n \t # TRIAL POINTS               : %6.0f',card_Z);
card_Zin=size(Zin,1);
fprintf('\n \t # TRIAL POINTS IN            : %6.0f',card_Zin);
card_nodes=size(xyw,1);
fprintf('\n \t # RULE POINTS                : %6.0f',card_nodes);
fprintf('\n \t # ITERATIONS INDOMAIN        : %6.0f',itlevel);
fprintf('\n \t RESIDUAL MOMENTS (norm2)     : %1.3e',res);w=xyw(:,3);
w=xyw(:,3); ik=find(w <= 0); NN=length(ik);
fprintf('\n \t NEGATIVE WEIGHTS             : %6.0f',NN);
w=xyw(:,3); condcub=sum(abs(w))/sum(w);
fprintf('\n \t # TRIAL POINTS IN 2019       : %6.0f',size(xywPG,1));
fprintf('\n \t CUBATURE CONDITIONING        : %1.3e',condcub);
fprintf('\n \t MEDIAN CPUTIME 2021          : %1.1e',cpusM(1));
fprintf('\n \t MEDIAN CPUTIME 2019          : %1.1e',cpusM(2));
fprintf('\n \t MONOMIAL BASIS MATCH 19-21 AE: %1.3e',norm(I1-I2,inf));
monbasRE=norm((I1-I2)./I2,inf);
fprintf('\n \t MONOMIAL BASIS MATCH 19-21 RE: %1.3e',monbasRE);
fprintf('\n ')
fprintf('\n \t -------------------------------------------');
fprintf('\n \t             PLOT DESCRIPTION');
fprintf('\n \t -------------------------------------------');
fprintf('\n \t * Green dots  : trial points in domain.  ');
fprintf('\n \t * Red dots    : trial points not in domain.  ');
fprintf('\n \t * Magenta dots: quadrature nodes.  ');
fprintf('\n \t * Cyan squares: NURBS control points.  ');
fprintf('\n \t -------------------------------------------');
fprintf('\n \t                   NOTE');
fprintf('\n \t -------------------------------------------');
fprintf('\n \t We have used only points for which it was ');
fprintf('\n \t fast the indomain determination. \n ');
fprintf('\n \t Thus some points that are clearly inside ');
fprintf('\n \t the domain are marked with "red" dots.');
fprintf('\n \t ------------------------------------------- \n');




%--------------------------------------------------------------------------
% ATTACHED ROUTINES
%--------------------------------------------------------------------------

function [geometry_NURBS,domain_str]=define_domain(example)

switch example

    case 1 % square/disk difference
        domain_str='domain 1';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));


        % add arc of an ellipse
        v=[0.5 0;0.5 0.5;0 0.5];
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);





    case 2 % polygon/disk union
        domain_str='domain 2';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0.25 0.25],'angles',[pi pi+pi/2],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.4 0.05; 0.5 0.25; 0.45 0.45; 0.3 0.5;0.1 0.45]; % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);





    case 3 % polygon/disk union
        domain_str='domain 3';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.25 0.2; 0.2 0.25];  % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);



    case 4 % polygon/disk union
        domain_str='domain 4';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.4 0.05; 0.5 0.25; 0.45 0.45; 0.3 0.5;0.1 0.45]; % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);



end






function [cc,r,a,b,v,conv]=define_domain_polycirc(test_type)

switch test_type

    case 1
        % TEST 1: concave arc
        cc=[0 0]; r=0.25; % circle defs; center "cc" and radius "r"
        a=[0.25 0]; % first point of the circle
        b=[0 0.25]; % last point of the circle
        v=[0.5 0;0.5 0.5;0 0.5]; % polygon vertices
        conv=0; % 0: concave arc

    case 2
        % TEST 2: convex arc
        cc=[0.25 0.25]; r=0.25; % circle defs; center "cc" and radius "r"
        a=[0.25 0]; % first point of the circle
        b=[0 0.25]; % last point of the circle
        v=[0.4 0.05; 0.5 0.25; 0.45 0.45; 0.3 0.5;0.1 0.45]; % polyg. vert.
        conv=1; % 1: convex arc

    case 3
        % TEST 3: concave arc
        cc=[0 0];r=0.25; % circle defs; center "cc" and radius "r"
        a=[0.25 0]; % first point of the circle
        b=[0 0.25]; % last point of the circle
        v=[0.25 0.2;0.2 0.25]; % polyg. vert.
        conv=0; % 0: concave arc

    case 4
        % TEST 4 convex arc
        cc=[0 0]; r=0.25; % circle defs; center "cc" and radius "r"
        a=[0.25 0]; % first point of the circle
        b=[0 0.25]; % last point of the circle
        v=[0.4 0.05; 0.5 0.25; 0.45 0.45; 0.3 0.5;0.1 0.45]; % polyg. vert.
        conv=0; % 0: concave arc

end









