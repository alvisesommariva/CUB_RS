
function demo_SPLINE_indomain_00

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating the INDOMAIN procedure:
% 1. how to define a SPLINE as parametric representation of the boundary, 
%    defining directly the spline structure by the function "makeSPLINEarc"
%    if 
%
%    a. control points,
%    b. knots 
%    c. order
%
%    are known.
%    The result is saved in the variable "geometry_SPLINE" of just one
%    component that take into account control points, knots, weights and
%    orders.
% 2. the application of the "joinNURBSPLarcs" is important in case the 
%    length of the vector "geometry_SPLINE" is larger than one, in order to
%    make a "consistent" piecewise SPLINE in which knots are well-ordered; 
%    since in this case there is just one arc, this routine is not called.
% 3. How to determine a tensorial pointset in the bounding box containing
%    the domain via the routine "ptsRS".
% 4. How to perform the INDOMAIN routine "inRS".
% 5. How to plot the domain and the points in terms of being inside or not 
%    inside the domain.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------

clear all; clf;

% ------------------------------ Settings ---------------------------------

% An equispaced tensor product grid is taken in a rectangle containing the 
% domain, with "Ngrid" equispaced points per direction.
Ngrid=50;


% ......................... Design SPLINE pieces  .........................

% Add arc of a disk: mantain the order of the variables as well as that of
% the strings.
geometry_SPLINE=makeSPLINEarc('free',...
    'P',[0 0; 1 0; 1 1; -2 1; 0 0],...
    'order',3);

% .........................  SPLINE indomain  ............................. 

% Define pointset (see routine at line 90).
pts=ptsRS(geometry_SPLINE,Ngrid);

% Apply indomain routine,
[in,in_doubts]=inRS(pts,geometry_SPLINE);


% ......................... Plot domain and points  .......................

h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis off; axis equal; axis tight;

% plot piecewise SPLINE curve
plotNURBSPL(geometry_SPLINE);

% Plot points inside the domain
iok=find(in == 1);
Xin=pts(iok,1); Yin=pts(iok,2);
plot(Xin,Yin,'go','MarkerSize',2);

% Plot points not inside the domain
iko=find(not(in == 1));
Xo=pts(iko,1); Yo=pts(iko,2);
plot(Xo,Yo,'ro','MarkerSize',2);

% Title
titlesrt=strcat('Indomain test:  ',num2str(Ngrid^2), ' points');
title(titlesrt);

hold off;


% ......................... Display statistics  ...........................

fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             NURBS CUBATURE TEST \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n');
fprintf('\n \t # TRIAL POINTS                : %6.0f',size(pts,1));
fprintf('\n \t # TRIAL POINTS IN             : %6.0f',size(Xin,1));
fprintf('\n');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             PLOT DESCRIPTION \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t * Green dots: points inside the domain.   \n \t');
fprintf('\n \t * Red dots: points not inside the domain.   \n \t');
fprintf('\n \t ------------------------------------------- \n');









