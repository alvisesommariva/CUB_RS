function [Sx,Sy]=compute_spline_boundary(X,Y,spline_parms,spline_type)

%..........................................................................
% OBJECT:
%
% This subroutine, starting from the sampling values of the boundary in X
% and Y (i.e. sampling points are the rows of the matrix [X Y]) it computes
% the parametrical description of the boundary in the "x" and "y" variable,
% via many spline, with possible different order, as described in
% "spline_parms".
%
% INPUT:
%
% X,Y: sampling points (X,Y) described as column vectors.
%
% spline_parms: spline order and block (vector).
%
%            [spline_parms(i,1)=2] : piecewise linear splines.
%            [spline_parms(i,1)=4] : cubic splines
%                         (depending on "spltypestring" in input).
%            [spline_parms(i,1)=k] : in the case k is not 2 or 4 it
%                          chooses the k-th order splines (for additional
%                          help digit "help spapi" in matlab shell).
%
%            [spline_parms(:,2)]: vector of final components of a block.
%
%            example:
%
%            "spline_parms=[2 31; 4 47; 8 67]" means that from the 1st
%             vertex to the 31th vertex we have an order 2 spline (piecewise
%             linear), from the 32th vertex to the 47th we use a 4th order
%             spline (i.e. a cubic and periodic spline by default), from
%             the 48th to the 67th (and final!) we use an 8th order spline.
%
% spline_type: in case of cubic spline, it describes the type of spline
%      by string. It is used by Matlab built-in routine "csape". Available
%      choices are found at
%
%             https://www.mathworks.com/help/curvefit/csape.html
%
%      and can be
%
%        'complete'   : match endslopes (as given in VALCONDS, with
%                     default as under *default*).
%       'not-a-knot' : make spline C^3 across first and last interior
%                     break (ignoring VALCONDS if given).
%       'periodic'   : match first and second derivatives at first
%                     data point with those at last data point (ignoring
%                     VALCONDS if given).
%       'second'     : match end second derivatives (as given in
%                    VALCONDS, with default [0 0], i.e., as in variational).
%       'variational': set end second derivatives equal to zero
%                     (ignoring VALCONDS if given).
%
% OUTPUT:
%
% Sx: vector whose k-th component is a spline describing the k-th spline
%     component describing the boundary, i.e. for certain [t(k),t(k+1] we
%     have that "x(t)=s(t)" with "s=Sx(k)".
%
% Sy: vector whose k-th component is a spline describing the k-th spline
%     component describing the boundary in the variable "y", i.e. for
%     certain [t(k),t(k+1] we have that "y(t)=s(t)" with "s=Sy(k)".
%
% Important note: Sx and Sy have the same "breaks" in each component, this
% meaning that "(Sx(k)).breaks=(Sy(k)).breaks".
%..........................................................................


% ................ troubleshooting ................ 

% Detting default as periodic cubic spline in case "spline_parms" is not
% declared.

if nargin < 3
    spline_parms=[4 length(X)]; 
end

if (nargin >= 3) & (length(spline_parms) == 1)
    spline_parms=[spline_parms length(X)]; 
end

if size(spline_parms,1) == 0
    spline_parms=[4 length(X)]; 
end

if nargin < 4
    spline_type='periodic';
end

% ................ splines definition ................ 

L=size(spline_parms,1);

for i=1:L % define spline
    
    % first and last index to consider
    if i == 1
        imin=1;
    else
        imin=spline_parms(i-1,2);
    end
    
    imax=spline_parms(i,2);
    
    tL=imin:imax; xL=X(imin:imax); yL=Y(imin:imax);
    
    [SxL,SyL]=compute_parametric_spline(tL,xL,yL,spline_parms(i,1),...
        spline_type);
    
    Sx(i)=SxL; Sy(i)=SyL;
    
end









%--------------------------------------------------------------------------
% compute_parametric_spline
%--------------------------------------------------------------------------

function [ppx,ppy]=compute_parametric_spline(s,x,y,spline_order,...
    spline_type)

%..........................................................................
% Object:
%
% Compute parametric spline relavant parameters "ppx", "ppy" so that a
% point at the boundary of the  domain has coordinates (x(s),y(s))
%
% Input:
% s: parameter data.
% x: determine spline x(s) interpolating (s,x)
% y: determine spline y(s) interpolating (s,y)
% spline_order: spline order (i.e. degree + 1)
% spline_type: string with the spline type i.e.
%             'complete'   : match endslopes (as given in VALCONDS, with
%                     default as under *default*).
%             'not-a-knot' : make spline C^3 across first and last interior
%                     break (ignoring VALCONDS if given).
%             'periodic'   : match first and second derivatives at first
%                     data point with those at last data point (ignoring
%                     VALCONDS if given).
%             'second'     : match end second derivatives (as given in
%                    VALCONDS, with default [0 0], i.e., as in variational).
%             'variational': set end second derivatives equal to zero
%                     (ignoring VALCONDS if given).
%     If "spline_type" is not declared or equal to "[]", we use 'periodic'.
%
% Output:
% ppx: spline x(t) data
% ppy: spline y(t) data
%..........................................................................

% ................ troubleshooting ................ 

% Detting default as periodic cubic spline in case "spline_parms" is not
% declared.
if nargin < 5
    spline_type = 'periodic';
end

if strlength(spline_type) == 0
    spline_type = 'periodic';
end


% ................ splines definition ................

% fprintf('\n \t order %3.0f: ',spline_order);
% tic;
switch spline_order
    case 4
        
        % Cubic splines: using "csape".
        ppx=csape(s,x,spline_type); ppy=csape(s,y,spline_type);
        
    otherwise
        
        % Non cubic splines: using "spapi".
        ppx=spapi(spline_order,s,x); ppy=spapi(spline_order,s,y);
        
end
% toc;

%..........................................................................
% Note:
%..........................................................................
% The routine "spapi" gives splines in "B-"form while "csape" in "pp"form.
% We brutally normalise them so to be in "pp" form, to simplify further 
% code. 
%
% The two forms are not equal, but provide "close" function (relative error
%  close to machine precision).
%
% This normalisation is requested to save all splines components as vector.
%..........................................................................

% fprintf('\n \t Changing form: ');
% tic;
if (ppx.form =='B-')
    ppx=fn2fm(ppx,'pp'); ppy=fn2fm(ppy,'pp');
end
% toc;








