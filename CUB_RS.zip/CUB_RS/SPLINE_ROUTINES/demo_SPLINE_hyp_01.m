
function demo_SPLINE_hyp_01

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Demo on how to define hyperinterpolation on a SPLINE composite boundary, 
% based on arcs of disks and polygonal arcs. 
%
% The fact that hyperinterpolant of degree "deg" is numerically exact,
% shows that cubature formula are exact.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 18, 2021;
% Checked: November 18, 2021.
%--------------------------------------------------------------------------

warning off;

% ......................... Problem Settings  ............................. 

deg=3; % hyperinterpolation degree
f=@(x,y) (1.2*x+1.5*y+1).^deg; % function to hyperinterpolate
Ngrid=100;


% ....................... Define domain structure ......................... 
x0=2;
geometry_RS(1)=makeSPLINEarc('disk_arc','center',[x0 -sqrt(2)/2],...
     'angles',[-pi pi/4],'radius',1);
 
Pstart=firstpointNURBSPL(geometry_RS(1));
 
geometry_RS(2)=makeSPLINEarc('disk_arc','center',[x0 +sqrt(2)/2],...
     'angles',[-pi/4 pi],'radius',1);
 
P0=lastpointNURBSPL(geometry_RS(2));
P1=[-P0(1) P0(2)];
geometry_RS(3)=makeSPLINEarc('segment','vertices',[P0; P1]);

center=P1-[1,0];
geometry_RS(4)=makeSPLINEarc('disk_arc','center',center,...
     'angles',[0 pi/4+pi],'radius',1);
 
center=[center(1) -center(2)];
geometry_RS(5)=makeSPLINEarc('disk_arc','center',center,...
     'angles',[pi-pi/4 2*pi],'radius',1);
 
P0=lastpointNURBSPL(geometry_RS(5));
P1=Pstart;
geometry_RS(6)=makeSPLINEarc('segment','vertices',[P0; P1]);

structure_RS=joinNURBSPLarcs(geometry_RS);




% ....................... Perform hyperinterpolation ......................

[coeff,R,jvec,dbox] = hypRSfit(deg,structure_RS,f);

% ............... Evaluate hyperinterpolant in points in domain ...........
pts=ptsRS(structure_RS,Ngrid); 
in=inRS(pts,structure_RS); iok=find(in == 1); pts0=pts(iok,:);
pval = hypRSval(deg,coeff,pts0,R,jvec,dbox);

% ............................ Test error .................................

fpts=feval(f,pts0(:,1),pts0(:,2));
AE=norm(pval-fpts,inf);

% ............................ Plot figure ................................

h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis equal;

% A. plot domain boundary
plotNURBSPL(structure_RS);

% B. plot test points.

plot(pts0(:,1),pts0(:,2),'g*','MarkerEdgeColor','g',...
    'MarkerFaceColor','g','MarkerSize',2);

hold off;

% ......................... Display statistics ............................
fprintf('\n \t Algebraic Degree of Exactness: %2.0g',deg);
fprintf('\n \t Absolute hyperinterp. error  : %1.3e \n',AE);

