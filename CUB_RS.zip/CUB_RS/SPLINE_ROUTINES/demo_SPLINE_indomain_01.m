
function demo_SPLINE_indomain_01

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating the INDOMAIN procedure:
% 1. how to define a SPLINE as parametric representation of the boundary, 
%    defining directly the spline structure by the function "makeSPLINEarc"
%    if 
%
%    a. control points,
%    b. knots 
%    c. order
%
%    are known.
%    The result is saved in the variable "geometry_SPLINE" of just one
%    component that take into account control points, knots, weights and
%    orders.
% 2. the application of the "joinNURBSPLarcs" is important in case the 
%    length of the vector "geometry_SPLINE" is larger than one, in order to
%    make a "consistent" piecewise SPLINE in which knots are well-ordered; 
%    since in this case there is just one arc, this routine is not called.
% 3. How to determine a tensorial pointset in the bounding box containing
%    the domain via the routine "ptsRS".
% 4. How to perform the INDOMAIN routine "inRS".
% 5. How to plot the domain and the points in terms of being inside or not 
%    inside the domain.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------

clear all; clf;

% ------------------------------ Settings ---------------------------------

% An equispaced tensor product grid is taken in a rectangle containing the 
% domain, with "Ngrid" equispaced points per direction.
Ngrid=50;


% ......................... Design SPLINE pieces  .........................

% add arc of a disk
fprintf('\n \t * Defining arc of a disk');
geometry_SPLINE(1)=makeSPLINEarc('disk_arc','center',[0 0],...
    'angles',[0 pi/2],'radius',1);

% compute last point of the so made SPLINE
fprintf('\n \t * Computing last point of a SPLINE');
Pend=lastpointNURBSPL(geometry_SPLINE);

% add arc of an ellipse
fprintf('\n \t * Defining arc of an ellipse');
geometry_SPLINE(2)=makeSPLINEarc('elliptical_arc',... 
    'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
    'tilt_angle',0);

% compute last point of the so made SPLINE
fprintf('\n \t * Computing last point of a SPLINE');
Pend=lastpointNURBSPL(geometry_SPLINE);

% add segment
fprintf('\n \t * Defining a polygonal_arc');
geometry_SPLINE(3)=makeSPLINEarc('polygonal_arc',...
    'extrema',[Pend; 0 Pend(2)]);

% compute first point of the piecewise SPLINE domain
fprintf('\n \t * Computing first point of a SPLINE');
Pinit=firstpointNURBSPL(geometry_SPLINE);

P=[0 Pend(2); -1.5 0.3; -1.3 0.5; Pinit];
knots=linspace(0,1,size(P,1));
geometry_SPLINE(4)=makeSPLINEarc('free','P',P,'order',3);

% ......................... Join SPLINE pieces  ...........................

% make unique SPLINE structure (very important step!)
fprintf('\n \t * Joining piecewise SPLINE into one well def. structure');
structure_SPLINE=joinNURBSPLarcs(geometry_SPLINE);

% .........................  SPLINE indomain  ............................. 

% Determine trial pointset.
fprintf('\n \t * Determine trial set');
pts=ptsRS(structure_SPLINE,Ngrid);

% Apply indomain routine.
fprintf('\n \t * Indomain routine');
[in,in_doubts]=inRS(pts,structure_SPLINE);


% ......................... Plot domain and points  .......................
fprintf('\n \t * Plot domain and points. \n \n');
figure(1)

hold on;
axis equal;
% plot piecewise SPLINE curve
plotNURBSPL(structure_SPLINE);

% Plot points inside the domain
iok=find(in == 1);
Xin=pts(iok,1); Yin=pts(iok,2);
plot(Xin,Yin,'go','MarkerSize',2);

% Plot points not inside the domain
iko=find(not(in == 1));
Xo=pts(iko,1); Yo=pts(iko,2);
plot(Xo,Yo,'ro','MarkerSize',2);

% Title
titlesrt=strcat('Indomain test:  ',num2str(Ngrid^2), ' points');
title(titlesrt);

hold off;



% ......................... Display statistics  ...........................

fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             NURBS CUBATURE TEST \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n');
fprintf('\n \t # TRIAL POINTS                : %6.0f',size(pts,1));
fprintf('\n \t # TRIAL POINTS IN             : %6.0f',size(Xin,1));
fprintf('\n');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             PLOT DESCRIPTION \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t * Green dots: points inside the domain.   \n \t');
fprintf('\n \t * Red dots: points not inside the domain.   \n \t');
fprintf('\n \t ------------------------------------------- \n');










