
function demo_SPLINE_cubature_02(domain_type)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating the CUBATURE procedure:
% 1. how to define a SPLINE on a composite boundary, using arcs of disks,
%    ellipses, segments, polygons and "free SPLINE". The routines work on
%    piecewise SPLINE of different order.
%    To this purpose see the MATLAB function "define_domain" at the
%    bottom of this demo.
% 2. how to call the indomain routine "cubRS".
% 3. comparison with the old spline routine "cubS"
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------

% ------------------------------ Settings ---------------------------------

% Algebraic degree of precision of the cubature rule. Suggested values are
% mild, e.g. not larger than "ade=15". Typical "ade" in the applications
% are between "3" and "5".
ade=5;

% Number of tests to determine the median cputime. We suggest to set
% "tests=10", while we do not recommend "tests=1" because it often turns
% out to provide unreliable cputimes.
% We remind that cputime may vary with the computer.
tests=10;

% Nbox is a technical parameter for indomain routine; in doubt set 100.
Nbox=1;

% In indomain routine one must be certain that points are inside the
% domain. In our cubature needs we just wants some points in the domain.
% Consequently, if we are not fully sure that a point is in the domain, due
% to geometrical issues, we do not take it into account.
safe_mode=0;

% The variable "domain_type" set the domain taken into account. The
% invented names are just given to remember something of the region.
%
%       0. Disk
%       1. Lune like
%       2. Tau-like-symbol
%       3. Quadrangloid
%       4. Curved trapezoid
%       5. Weird eta
%       6. Weird eta 2
%       7. Weird eta 3
%       8. Weird eta skinny
%       9. Rough ball
%      10. L-shaped
%      11. M-shaped domain
%      12. defined by a disk, an ellipse and a segment
%      13. defined by a disk, an ellipse, a segment and a free SPLINE
%          (variable order)
%      otherwise: defined by a disk, an ellipse, a segment and a free SPLINE
%          (variable order)
if nargin < 1
   domain_type=11;
end






% ----------------------------- Main code ---------------------------------

%--------------------------------------------------------------------------
% 1. Make SPLINE structure
%--------------------------------------------------------------------------

[geometry_SPLINE,domain_str]=define_domain(domain_type);


%--------------------------------------------------------------------------
% 2. Generate test points (tensorial grid on a rectangle containing domain)
%--------------------------------------------------------------------------

% SPLINE control points.
P=[];
for k=1:length(geometry_SPLINE)
    geometry_SPLINEL=geometry_SPLINE(k); PL=geometry_SPLINEL.P; P=[P; PL];
end



%--------------------------------------------------------------------------
% 3. Indomain (several cputime tests!).
%--------------------------------------------------------------------------
fprintf('\n \t ');
for k=1:tests
    tic;
    [xyw,res,Z,Zin,cmom,bbox,itlevel] = cubRS(ade,geometry_SPLINE);
    cpus(k)=toc;
end


%--------------------------------------------------------------------------
% 4. Plot domain and control points polygon.
%--------------------------------------------------------------------------

h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis equal;

% A. plot SPLINE curve (black)
plotNURBSPL(geometry_SPLINE);

% B. plot nodes.

plot(Z(:,1),Z(:,2),'r*','MarkerEdgeColor','r',...
    'MarkerFaceColor','r','MarkerSize',4);

plot(Zin(:,1),Zin(:,2),'g*','MarkerEdgeColor','g',...
    'MarkerFaceColor','g','MarkerSize',4);

plot(xyw(:,1),xyw(:,2),'mo','MarkerEdgeColor','k',...
    'MarkerFaceColor','m','MarkerSize',10);


hold off;

%--------------------------------------------------------------------------
% 4. Display statistics.
%--------------------------------------------------------------------------

fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t          SPLINE CUBATURE TESTS \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t DOMAIN: '); disp(domain_str);
fprintf('\n');
fprintf('\n \t ALGEBRAIC DEGREE OF PRECISION: %6.0f',ade);
fprintf('\n \t # CONTROL POINTS             : %6.0f',size(P,1));
fprintf('\n \t # TRIAL POINTS               : %6.0f',size(Z,1));
fprintf('\n \t # TRIAL POINTS IN DOMAIN     : %6.0f',size(Zin,1));
fprintf('\n \t # ITERATIONS                 : %6.0f',itlevel);
fprintf('\n \t # MOMENTS MATCHING (NORM 2)  : %1.1e',res);
fprintf('\n \t MEDIAN CPUTIME 2021          : %1.1e',median(cpus));
fprintf('\n \t CPUTIME TESTS                : %6.0f',tests);
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             PLOT DESCRIPTION \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t * Green dots: points inside the domain.   \n \t');
fprintf('\n \t * Red dots: points not inside the domain.   \n \t');
% fprintf('\n \t * Cyan squares: control points.   \n \t');
% fprintf('\n \t * Black dotted lines: control polygon.   \n \t');
fprintf('\n \t * Magenta diamonds: boundary singular points.   \n \t');
fprintf('\n \t ------------------------------------------- \n');











%--------------------------------------------------------------------------
% ATTACHED ROUTINES
%--------------------------------------------------------------------------

function [geometry_SPLINE,domain_str]=define_domain(example)

switch example
    
    case 0 % circle
        domain_str='circle';
        geometry_SPLINE=makeSPLINEarc('disk_arc','center',[0 0],...
            'angles',[0 2*pi],'radius',1);
        
        
    case 1 % lune-like
        domain_str='lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        order=3;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
        
    case 2
        domain_str='Tau-like-symbol';
        P=[1 0; 0.8 0.1; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5;  ...
            0.2 -0.45; -0.4 -0.4; 0 -1; 1 -1;  1 0];
        order=3;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
        
    case 3
        domain_str='Quadrangloid';
        P=[1 0; 1 1; 0 1; -1 1; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        order=4;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
        
        
    case 4
        domain_str='Curved trapezoid';
        P=[1 0; 1 1; 0 1; -1 0.6; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        order=4;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
        
    case 5
        domain_str='Weird eta';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.1 0.1; 0 0.5; 1 -1;  1 0];
        order=4;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
    case 6
        domain_str='Weird eta 2';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 -1; 0 0.5; 1 -1;  1 0];
        order=4;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
        
    case 7
        domain_str='Weird eta 3';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.4 0.6; 0 -0.5; 1 -1;  1 0];
        order=4;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
    case 8
        domain_str='Weird eta skinny';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 0.5; 1 -1;  1 0];
        order=4;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
    case 9 % rough-ball
        domain_str='rough ball';
        sidesL=20;
        t=linspace(0,2*pi,sidesL); t=t';
        P=[cos(t) sin(t)]; P=[P(1:end-1,:); P(1,:)];
        order=3;
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
    case 10 % L-shaped domain
        
        domain_str='L shaped domain';
        P=[-1 1; -1 -1; 1 -1; 1 -0.6; -0.6 -0.6; -0.6 1; -1 1]; % 7 points
        order=3;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
    case 11 % M-shaped domain
        
        domain_str='M shaped domain';
        order=3;
        P=[-1 1; -1 0; -1 -1; -0.6 -1; -0.6 0; -0.6 0.6; 0 0; 0.6 0.6; ...
            0.6 0; 0.6 -1; 1 -1; 1 0; 1 1; 0.6 1; 0 0.4; -0.6 1; -1 1];
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
    case 12 % variable order
        domain_str='domain 12, defined by a disk, an ellipse and a segment';
        
        
        % add arc of a disk
        geometry_SPLINE(1)=makeSPLINEarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);
        
        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE(1));
        
        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(1));
        
        % add arc of an ellipse
        geometry_SPLINE(2)=makeSPLINEarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);
        
        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(2));
        
        % "close" the boundary with a segment
        geometry_SPLINE(3)=makeSPLINEarc('segment','extrema',[Pend; Pinit]);
        
        % join piecewise SPLINE
        geometry_SPLINE=joinNURBSPLarcs(geometry_SPLINE);
        
    case 13 % variable order
        domain_str1='domain 13, defined by a disk, an ellipse, a segment';
        domain_str2=' and a free SPLINE (variable order)';
        domain_str=strcat(domain_str1,domain_str2);
        
        % add arc of a disk
        geometry_SPLINE(1)=makeSPLINEarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);
        
        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE(1));
        
        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(end));
        
        % add arc of an ellipse
        geometry_SPLINE(2)=makeSPLINEarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);
        
        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(end));
        
        % add segment
        geometry_SPLINE(3)=makeSPLINEarc('segment','extrema',[Pend; 0 Pend(2)]);
        
        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE);
        
        % "close" the boundary with a "free" SPLINE.
        geometry_SPLINE(4)=makeSPLINEarc('free',...
            'P',[0 Pend(2); -1.2 0.3; -1.0 0.5; Pinit],'order',4);
        
        % join piecewise SPLINE
        geometry_SPLINE=joinNURBSPLarcs(geometry_SPLINE);
        
        
        
    otherwise % variable order
        domain_str1='domain defined by a disk, an ellipse, a segment';
        domain_str2=' and a free SPLINE (variable order)';
        domain_str=strcat(domain_str1,domain_str2);
        
        % add arc of a disk
        geometry_SPLINE(1)=makeSPLINEarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);
        
        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE(1));
        
        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(end));
        
        % add arc of an ellipse
        geometry_SPLINE(2)=makeSPLINEarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);
        
        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(end));
        
        % add segment
        geometry_SPLINE(3)=makeSPLINEarc('segment','extrema',[Pend; 0 Pend(2)]);
        
        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE);
        
        % "close" the boundary with a "free" SPLINE.
        geometry_SPLINE(4)=makeSPLINEarc('free',...
            'P',[0 Pend(2); -1.9 0.3; -1.8 0.5; Pinit],'order',3);
        
        % join piecewise SPLINE
        geometry_SPLINE=joinNURBSPLarcs(geometry_SPLINE);
end


