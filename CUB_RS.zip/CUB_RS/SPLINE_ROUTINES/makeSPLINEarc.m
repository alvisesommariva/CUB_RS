
function geometry_SPLINE=makeSPLINEarc(domain_str,varargin)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This routine, given a certain domain by its geometrical definitions
% provides the relative SPLINE parameters (control points, weights, knots,
% order) storing them in a structured array "structure_arc".
% See demos in the folder for defining geometries.
%
% Important: arc of disks and ellipses are only approximated.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% First version: October 31, 2021;
% Checked: November 18, 2021.
%--------------------------------------------------------------------------

switch domain_str
    case 'disk_arc'
        %% Example of the outer call:
        % geometry_SPLINE=makeSPLINEarc('disk_arc',...
        % 'center',[0 0],'angles',[0 pi/2],'radius',1);
        center=varargin{2}; theta=varargin{4}; r=varargin{6};
        
        % discretization interval theta in Npts segments
        precision='low';
        switch precision
            case 'low'
                Npts=10; % CIRCLE: MAX ABS. ERR. 10^(-5)
            case 'mid'
                Npts=70; % CIRCLE: MAX ABS. ERR. 5.1655e-09
            case 'high'
                Npts=200;  % CIRCLE: MAX ABS. ERR. 7.4374e-11
        end
        
        [P,w,knots,order]=compute_arcspl_parms(center,r,...
            theta(1),theta(2),Npts);
        
    case 'elliptical_arc'
        %% Example of the outer call:
        % geometry_SPLINE=makeSPLINEarc('elliptical_arc',...
        % 'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
        % 'tilt_angle',0);
        center=varargin{2}; theta=varargin{4}; ell_axis=varargin{6};
        if nargin < 8
            tilt_angle = 0;
        else
            tilt_angle=varargin{8};
        end
        
        % discretization interval theta in Npts segments
        precision='low';
        
        switch precision
            case 'low' 
                Npts=10; % MAX A.E. 9e-03, if ell_axis=[1 2],th=[0 2*pi].
            case 'mid'
                Npts=70; % MAX A.E. 2e-06, if ell_axis=[1 2],th=[0 2*pi].
            case 'high'
                Npts=200; % MAX A.E. 3e-08, if ell_axis=[1 2],th=[0 2*pi].
        end
        
        [P,w,knots,order]=compute_ellarcspl_parms(center,theta,ell_axis,...
            tilt_angle,Npts);
        
    case 'polygonal_arc'
        %% Example of the outer call:
        % geometry_SPLINE=makeSPLINEarc('polygonal_arc',...
        % 'vertices',[1 0; 1 1; 0 0]);
        vertices=varargin{2};
        [P,w,knots,order]=compute_polygonspl_parms(vertices);
        
    case 'segment'
        %% Example of the outer call:
        % geometry_SPLINE=makeSPLINEarc('polygonal_arc',...
        % 'vertices',[1 0; 1 1]);
        vertices=varargin{2};
        [P,w,knots,order]=compute_segmentsspl_parms(vertices);
        
    case 'free'
        %% Example of the outer call:
        % geometry_SPLINE=makeSPLINEarc('free',...
        % 'P',[-2 1; -1.9 0.3; -1.8 0.5; -1.7 5],'order',3);
        P=varargin{2}; order=varargin{4};
        if nargin >= 6
            knots=varargin{6};
        else
            L=size(P,1);
            knots=linspace(0,1,L);
        end
        
        w=[];
end

geometry_SPLINE.P=P;
geometry_SPLINE.w=[];
geometry_SPLINE.knots=knots;
geometry_SPLINE.order=order;
geometry_SPLINE.type='spline';
geometry_SPLINE.shape=domain_str;












%--------------------------------------------------------------------------
% ATTACHED ROUTINES:
%--------------------------------------------------------------------------
% 1. compute_arcspl_parms
% 2. compute_ellarcspl_parms
% 3. compute_polygonspl_parms
% 4. compute_segmentsspl_parms
%--------------------------------------------------------------------------


function [P,w,knots,order]=compute_arcspl_parms(center,r,theta0,theta1,...
    Npts)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This routine defines an arc of circle.
% Arc equation (without tilting):
% * x(t)=center(1)+r*cos(t)
% * y(t)=center(2)+r*sin(t)
% with "theta" in "[theta0,theta1]".
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% center: center of the circle containing the arc.
% r: radius of the circle containing the arc.
% theta0,theta1: angles of the extrema of the arc.
% Npts: number of equispaced points to approximatively needed to
%    approximate arc.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% P: control points.
% w: SPLINE weights.
% knots: SPLINE weights.
% order: SPLINE order.
%--------------------------------------------------------------------------
% DATE:
%--------------------------------------------------------------------------
% Written: November 4, 2021.
% Checked: November 18, 2021.
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% Troubleshooting.
%--------------------------------------------------------------------------

if nargin < 1, center=[0 0]; end
if nargin < 2, r=1; end
if nargin < 3, theta0=0; end
if nargin < 4, theta1=2*pi; end
if nargin < 5, Npts=100; end

if isempty(center), center=[0 0]; end
if isempty(r), r=1; end
if isempty(theta0), theta0=0; end
if isempty(theta1), theta1=1; end
if isempty(Npts), Npts=100; end

if theta0 > theta1
    flag=0; [theta1,theta0]=deal(theta0,theta1);
else
    flag=1;
end

%--------------------------------------------------------------------------
% Control points.
%--------------------------------------------------------------------------

t=linspace(theta0,theta1,Npts); t=t'; if flag == 0, t=flipud(t); end
P=bsxfun(@plus,center,r*[cos(t) sin(t)]);

%--------------------------------------------------------------------------
% Other outputs.
%--------------------------------------------------------------------------

w=[];
L=size(P,1); knots=linspace(0,1,L);
order=4;












function [P,w,knots,order]=compute_ellarcspl_parms(center,theta,...
    ell_axis,tilt_angle,Npts)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This routine defines an arc of ellipse (possibly tilted).
% Ellipse equation (without tilting):
% * x(t)=center(1)+a*cos(t)
% * y(t)=center(2)+b*sin(t)
%
% IMPORTANT:
% For the spline case, the ellipse is ONLY an approximation of the needed
% one.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% center: center of the ellipse
% theta: angles of the extrema of the elliptical arc.
% ell_axis: it is a 2 x 1 vector, where the first component describes the
%         half width "a" while the second component described the half
%         height "b".
% tilt_angle: angle of rotation of the ellipse with respect to the x-axis;
%         this variable is not mandatory (default value: 0).
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% P: control points.
% w: SPLINE weights.
% knots: SPLINE weights.
% order: SPLINE order.
%--------------------------------------------------------------------------
% DATE:
%--------------------------------------------------------------------------
% Written: November 4, 2021.
% Checked: November 18, 2021.
%--------------------------------------------------------------------------

% .......................... Troubleshooting  ..........................
if nargin < 1, center=[0 0]; end
if nargin < 2, theta=[0 2*pi]; end
if nargin < 3, ell_axis=[1 1]; end
if nargin < 4, tilt_angle=0; end
if nargin < 5, Npts=100; end

theta0=theta(1); theta1=theta(2);
a=ell_axis(1); b=ell_axis(2);

%  .......................... Determine outputs ...........................

% Basis set via circle.
center0=[0 0]; r0=1;

[P,w,knots,order]=compute_arcspl_parms(center0,r0,theta0,theta1,...
    Npts);

P=[a*P(:,1) b*P(:,2)];

if not(tilt_angle == 0)
    R=[cos(tilt_angle) -sin(tilt_angle); sin(tilt_angle) cos(tilt_angle)];
    P=P*R';
end

P=bsxfun(@plus,center,P);
w=[];

order=4;

L=size(P,1); knots=linspace(0,1,L); % equispaced parametrization.












function [P,w,knots,order]=compute_polygonspl_parms(vertices)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This routine defines the sides of a polygonal arc (possibly open!).
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% vertices: vertices of the arcs of the polygon (oriented counterclockwise)
%           as N x 2, where "N" is the number of vertices, that are
%           described in cartesian coordinates.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% P: control points.
% w: SPLINE weights.
% knots: SPLINE weights.
% order: SPLINE order.
%--------------------------------------------------------------------------
% DATE:
%--------------------------------------------------------------------------
% Written: November 4, 2021.
%--------------------------------------------------------------------------

Npts=size(vertices,1);
P=vertices;
knots=(0:Npts-1)/(Npts-1);
w=ones(1,size(P,1));
order=2;












function [P,w,knots,order]=compute_segmentsspl_parms(vertices)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This routine defines a segment with vertices, via SPLINE.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% center=varargin{2};: extrema of the segment joining P0 to P2.
% It is a 2 x 2 matrix where the k-th row describes the k-th point.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% P: control points.
% w: SPLINE weights.
% knots: SPLINE weights.
% order: SPLINE order.
%--------------------------------------------------------------------------
% DATE:
%--------------------------------------------------------------------------
% Written: November 7, 2021.
%--------------------------------------------------------------------------

Npts=size(vertices,1);
P=vertices;
knots=(0:Npts-1)/(Npts-1);
w=ones(1,size(P,1));
order=2;









