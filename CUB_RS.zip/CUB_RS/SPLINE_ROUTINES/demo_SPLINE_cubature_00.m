
function demo_SPLINE_cubature_00

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating the CUBATURE procedure:
% 1. how to define a SPLINE on a composite boundary, using defining 
%    directly the spline structure by the function "makeSPLINEarc" if 
%
%    a. control points,
%    b. knots 
%    c. order
%
%    are known.
%    The result is saved in the variable "geometry_SPLINE" of just one
%    component that take into account control points, knots, weights and
%    orders.
% 2. the application of the "joinNURBSPLarcs" is important in case the 
%    length of the vector "geometry_SPLINE" is larger than one, in order to
%    make a "consistent" piecewise SPLINE in which knots are well-ordered; 
%    since in this case there is just one arc, this routine is not called.
% 3. cubature by means of "cubRS" from the built structure.
% 4. plot of the domain, by means of "plotNURBSPL" directly by the
%    structure.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------

clear all; clf;


% ------------------------------ Settings ---------------------------------

% Algebraic degree of precision of the cubature rule. Suggested values are
% mild, e.g. not larger than "ade=15". Typical "ade" in the applications
% are between "3" and "5".
ade=5;


% ......................... Design SPLINE pieces  .........................

% Add arc of a disk: mantain the order of the variables as well as that of
% the strings.
geometry_SPLINE=makeSPLINEarc('free',...
    'P',[0 0; 1 0; 1 1; -2 1; 0 0],...
    'order',3);

% .........................  SPLINE indomain  ............................. 

%--------------------------------------------------------------------------
% 1. Cubature.
%--------------------------------------------------------------------------
xyw = cubRS(ade,geometry_SPLINE);

%--------------------------------------------------------------------------
% 2. Plot domain and control points polygon.
%--------------------------------------------------------------------------

h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis equal;

% A. plot SPLINE curve (black)
plotNURBSPL(geometry_SPLINE);

% B. plot nodes.
plot(xyw(:,1),xyw(:,2),'mo','MarkerEdgeColor','k',...
    'MarkerFaceColor','m','MarkerSize',10);

hold off;

fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t            SPLINE CUBATURE TESTS \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n');
fprintf('\n \t ALGEBRAIC DEGREE OF PRECISION: %3.0f',ade);
w=xyw(:,3); condcub=sum(abs(w))/sum(w);
fprintf('\n \t CUBATURE CONDITIONING        : %1.5e',condcub);
NN=length(find(xyw(:,3) == 0));
fprintf('\n \t NEGATIVE WEIGHTS             : %6.0f',NN);
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             PLOT DESCRIPTION \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t * Magenta dots: quadrature nodes.   \n \t');
fprintf('\n \t ------------------------------------------- \n');





