
function demo_BEZIER_indomain_00

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Demo on INDOMAIN procedure.
% 1. how to define a BEZIER composite boundary, using arcs of disks,
%    and "polygonal arcs".
% 2. how to define an equispaced pointset on the domain via "ptsRS".
% 3. how to perform indomain analysis via "inRS".
% 4. how to plot the domain by "plotNURBSPL".
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------

% .......................... Define Boundary  ............................. 

% Number of equispaced points of the tensor grid per dimension. The total
% number of points will be Ngrid^2.
Ngrid=100;

% Define structure of an "Ice cream cone with one scoop".
geometry_BEZIER(1)=makeBEZIERarc('disk_arc','center',[0 0],...
     'angles',[0 pi],'radius',1);
geometry_BEZIER(2)=makeBEZIERarc('polygonal_arc','vertices',...
    [-1 0; 0 -1; 1 0]);

% Join blocks.
structure_BEZIER=joinNURBSPLarcs(geometry_BEZIER);


% .......................... Trial Pointset ...............................
pts=ptsRS(structure_BEZIER,Ngrid);


% .......................... Indomain routine .............................
[in,in_doubts]=inRS(pts,structure_BEZIER);


% ....................... Plot domain and pointset ........................

clf;
figure(1)
axis equal
hold on;

% A. plot curve.
plotNURBSPL(geometry_BEZIER);

% B. plot trial points.
plot(pts(:,1),pts(:,2),'r*');

% C.plot trial points in domain.
in_ok=find(in == 1);
plot(pts(in_ok,1),pts(in_ok,2),'g*');

hold off;


% ......................... Display statistics  ...........................

fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             BEZIER INDOMAIN TEST \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n');
fprintf('\n \t # TRIAL POINTS                : %6.0f',size(pts,1));
fprintf('\n \t # TRIAL POINTS IN             : %6.0f',length(in_ok));
fprintf('\n');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             PLOT DESCRIPTION \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t * Green dots: points inside the domain.   \n \t');
fprintf('\n \t * Red dots: points not inside the domain.   \n \t');
fprintf('\n \t ------------------------------------------- \n');







