
function demo_BEZIER_definedomain_00

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Demo on how to define a BEZIER composite boundary, using arcs of disks,
% polygonal arcs. 
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 14, 2021.
%--------------------------------------------------------------------------

% Define structure of an "Ice cream cone with one scoop".
geometry_BEZIER(1)=makeBEZIERarc('disk_arc','center',[0 0],...
     'angles',[0 pi],'radius',1);
geometry_BEZIER(2)=makeBEZIERarc('polygonal_arc','vertices',...
    [-1 0; 0 -1; 1 0]);

% Important. Join blocks.
structure_BEZIER=joinNURBSPLarcs(geometry_BEZIER);

% Plot figure
clf;
figure(1)
axis equal
hold on;
plotNURBSPL(geometry_BEZIER);
hold off;



