
function demo_BEZIER_indomain_01

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo on 
% Demo on INDOMAIN procedure.
% 1. how to define a BEZIER composite boundary, using arcs of an ellipse,
%    and "free Bezier", i.e. a Bezier arc defined by control points and 
%    order.
% 2. how to define an equispaced pointset on the domain via "ptsRS".
% 3. how to perform indomain analysis via "inRS".
% 4. how to plot the domain by "plotNURBSPL".
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------


% .......................... Define Boundary  ............................. 
% Define first structure of the curve (an ellipse).
geometry_BEZIER(1)=makeBEZIERarc('elliptical_arc','center',[1 5],...
     'angles',[0 pi],'ell_axis',[2 1]);

% Last point of the previous curve. 
P0=lastpointNURBSPL(geometry_BEZIER(end));

% First point of the previous curve. 
P1=firstpointNURBSPL(geometry_BEZIER(end));

% Define next structure of the curve (an ellipse). 
P=[P0; 0 -0.5; 0 -0.7; P1];
geometry_BEZIER(2)=makeBEZIERarc('free','P',P,'order',4);
        
% Important: Join the structures if they are more then one.
structure_BEZIER=joinNURBSPLarcs(geometry_BEZIER);        


% .......................... Trial Pointset ...............................
pts=ptsRS(structure_BEZIER,100);


% .......................... Indomain routine .............................
[in,in_doubts]=inRS(pts,structure_BEZIER);


% ....................... Plot domain and pointset ........................
clf;
figure(1)
axis equal
hold on;
% A. plot curve
plotNURBSPL(structure_BEZIER);

% B. plot trial points
plot(pts(:,1),pts(:,2),'r*');

% C.plot trial points in domain
in_ok=find(in == 1);
plot(pts(in_ok,1),pts(in_ok,2),'g*');

hold off;


% ......................... Display statistics  ...........................

fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             BEZIER INDOMAIN TEST \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n');
fprintf('\n \t # TRIAL POINTS                : %6.0f',size(pts,1));
fprintf('\n \t # TRIAL POINTS IN             : %6.0f',length(in_ok));
fprintf('\n');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             PLOT DESCRIPTION \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t * Green dots: points inside the domain.   \n \t');
fprintf('\n \t * Red dots: points not inside the domain.   \n \t');
fprintf('\n \t ------------------------------------------- \n');







