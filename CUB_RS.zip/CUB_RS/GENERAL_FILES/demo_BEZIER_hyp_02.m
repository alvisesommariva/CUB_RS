
function demo_BEZIER_hyp_02(domain_type)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Demo on how to define hyperinterpolation on a BEZIER composite boundary,
% based on arcs of disks and polygonal arcs.
%
% The fact that hyperinterpolant of degree "deg" is numerically exact,
% shows that cubature formula are exact.
%--------------------------------------------------------------------------
% Note
%--------------------------------------------------------------------------
% We provide experiments testing hyperinterpolant reconstruction at degree
% "n" of a polynomial of degree "n". The error seems to increase with the
% degree. Below the example on the L-domain (domain_type=10).
%
% >> demo_BEZIER_hyp_02
%
%  	 Alg. Degree of Exactness    :  2
%  	 Non filtered inf.norm error : 1.332e-15
%  	 Filtered inf.norm error     : 1.332e-15
%  	 Median inf.norm error       : 2.082e-16 
%  
% >> demo_BEZIER_hyp_02
% 
%  	 Alg. Degree of Exactness    :  4
%  	 Non filtered inf.norm error : 2.864e-14
%  	 Filtered inf.norm error     : 2.864e-14
%  	 Median inf.norm error       : 7.596e-15 
%  
% >> demo_BEZIER_hyp_02
% 
%  	 Alg. Degree of Exactness    :  6
%  	 Non filtered inf.norm error : 3.826e-13
%  	 Filtered inf.norm error     : 3.826e-13
%  	 Median inf.norm error       : 9.934e-14 
%  
% >> demo_BEZIER_hyp_02
% 
%  	 Alg. Degree of Exactness    :  8
%  	 Non filtered inf.norm error : 3.780e-12
%  	 Filtered inf.norm error     : 3.780e-12
%  	 Median inf.norm error       : 5.788e-13 
%  
% >> demo_BEZIER_hyp_02
% 
%  	 Alg. Degree of Exactness    : 10
%  	 Non filtered inf.norm error : 1.836e-10
%  	 Filtered inf.norm error     : 1.836e-10
%  	 Median inf.norm error       : 1.528e-11 
%  
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 18, 2021;
% Checked: November 18, 2021.
%--------------------------------------------------------------------------

warning off;

% ......................... Problem Settings  .............................

deg=4; % hyperinterpolation degree

% The variable "domain_type" set the domain taken into account. The
% invented names are just given to remember something of the region.
%
%       0. Disk
%       1. Lune like
%       2. Tau-like-symbol
%       3. Quadrangloid
%       4. Curved trapezoid
%       5. Weird eta
%       6. Weird eta 2
%       7. Weird eta 3
%       8. Weird eta skinny
%       9. Rough ball
%      10. L-shaped
%      11. M-shaped domain
%      12. defined by a disk, an ellipse and a segment
%      13. defined by a disk, an ellipse, a segment and a free "spline"
%          (variable order)
%      otherwise: defined by a disk, an ellipse, a segment and a free RS
%          domain (variable order)
if nargin < 1, domain_type=10; end

f=@(x,y) (1.2*x+1.5*y+1).^deg; % function to hyperinterpolate
Ngrid=100;


% ....................... Define domain structure .........................

[structure_RS,domain_str]=define_domain(domain_type);

% ....................... Perform hyperinterpolation ......................

[coeff,R,jvec,dbox] = hypRSfit(deg,structure_RS,f);

% ............... Evaluate hyperinterpolant in points in domain ...........
pts=ptsRS(structure_RS,Ngrid);
in=inRS(pts,structure_RS); iok=find(in == 1); pts0=pts(iok,:);
pval = hypRSval(deg,coeff,pts0,R,jvec,dbox);

% ............................ Test error .................................

fpts=feval(f,pts0(:,1),pts0(:,2));

% we do not consider points with too large or too small values. Of the
% remaining ones we test the quality of the approximation.

AEs=abs(pval-fpts);
AE0=norm(pval-fpts,inf);
tol=10^(-12);
iok=find(fpts >= tol & fpts <=1/tol);
if length(iok) > 0
    pval0=pval(iok); fpts0=fpts(iok);
    AE=norm(pval0-fpts0,inf);
    RE=norm((pval0-fpts0)./fpts0,inf);
else
    AE=NaN;
end





% ............................ Plot figure ................................

h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis equal;

% A. plot domain boundary
plotNURBSPL(structure_RS);

% B. plot test points.

plot(pts0(:,1),pts0(:,2),'g*','MarkerEdgeColor','g',...
    'MarkerFaceColor','g','MarkerSize',2);

hold off;

% ......................... Display statistics ............................
fprintf('\n \t Alg. Degree of Exactness    : %2.0f',deg);
fprintf('\n \t Non filtered inf.norm error : %1.3e',AE0);
fprintf('\n \t Filtered inf.norm error     : %1.3e',AE);
fprintf('\n \t Median inf.norm error       : %1.3e \n \n',median(AEs));








%--------------------------------------------------------------------------
% ATTACHED ROUTINES
%--------------------------------------------------------------------------



%--------------------------------------------------------------------------
% ATTACHED ROUTINES
%--------------------------------------------------------------------------

function [geometry_BEZIER,domain_str]=define_domain(example)

switch example
    
    case 0 % circle
        domain_str='circle';
        geometry_BEZIER=makeBEZIERarc('disk_arc','center',[0 0],...
            'angles',[0 2*pi],'radius',1);
        
        
    case 1 % lune-like
        domain_str='lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        order=4;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
        
    case 2
        domain_str='Tau-like-symbol';
        P=[1 0; 0.8 0.1; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5;  ...
            0.2 -0.45; -0.4 -0.4; 0 -1; 0.5 -1; 1 -1;  1 0];
        order=3;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
        
    case 3
        domain_str='Leaf-like';
        P=[1 0; 1 1; 0 1; -1 1; -1 0; -1 -1; 0 -1; 1 -1; 1 -0.5; 1 0];
        order=4;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
        
        
    case 4
        domain_str='Curved trapezoid: glasses lens';
        P=[1 0; 1 1; 0 1; -1 0.6; -1 0; -1 -1; 0 -1; 1 -1; 1 -0.7; 1 0];
        order=4;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
        
    case 5
        domain_str='Weird eta';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.1 0.1; ...
            0 0.5; 1 -1;  1 -0.7;   1 0];
        order=4;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
    case 6
        domain_str='Weird eta 2';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 -1; 0 0.5; ...
            1 -1; 1 -0.7;  1 0];
        order=6;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
        
    case 7
        domain_str='Weird eta 3';
        P=[1 0; 1 1; 0 1;  -1 0; -1 -0.7; -1 -1; -0.4 -0.2; 0 -0.5; ...
            1 -1;  1 0];
        order=4;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
    case 8
        domain_str='Weird eta skinny';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 0.5; 1 -1; 0.5 0.2;1 0];
        order=4;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
    case 9 % rough-ball
        domain_str='rough ball';
        sidesL=21;
        t=linspace(0,2*pi,sidesL); t=t';
        P=[cos(t) sin(t)]; P=[P(1:end-1,:); P(1,:)];
        order=5;
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
    case 10 % L-shaped domain
        
        domain_str='L shaped domain';
        P=[-1 1; -1 0; -1 -0.5; -1 -1; 1 -1; 1 -0.6; -0.6 -0.6; ...
            -0.6 1; -1 1]; % 7 points
        order=3;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
    case 11 % M-shaped domain
        
        domain_str='M shaped domain';
        order=3;
        P=[-1 1; -1 0; -1 -1; -0.6 -1; -0.6 0; -0.6 0.6; 0 0; 0.6 0.6; ...
            0.6 0; 0.6 0.5; 0.6 -1;  1 -1; 1 0; 1 1; 0.88 1.07; 0.6 1; ...
            0 0.4; -0.6 1; -0.76 1.03; -0.88 1.07; -1 1];
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
    case 12 % variable order
        domain_str='domain 12, defined by a disk, an ellipse and a segment';
        
        
        % add arc of a disk
        geometry_BEZIER(1)=makeBEZIERarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);
        
        % compute first point of the piecewise BEZIER domain
        Pinit=firstpointNURBSPL(geometry_BEZIER(1));
        
        % compute last point of the so made BEZIER
        Pend=lastpointNURBSPL(geometry_BEZIER(1));
        
        % add arc of an ellipse
        geometry_BEZIER(2)=makeBEZIERarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],...
            'ell_axis',[1 2],'tilt_angle',0);
        
        % compute last point of the so made BEZIER
        Pend=lastpointNURBSPL(geometry_BEZIER(2));
        
        % "close" the boundary with a segment
        geometry_BEZIER(3)=makeBEZIERarc('segment','extrema',...
            [Pend; Pinit]);
        
        % join piecewise BEZIER
        geometry_BEZIER=joinNURBSPLarcs(geometry_BEZIER);
        
    case 13 % variable order
        domain_str1='domain 13, defined by a disk, an ellipse, a segment';
        domain_str2=' and a free BEZIER (variable order)';
        domain_str=strcat(domain_str1,domain_str2);
        
        % add arc of a disk
        geometry_BEZIER(1)=makeBEZIERarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);
        
        % compute first point of the piecewise BEZIER domain
        Pinit=firstpointNURBSPL(geometry_BEZIER(1));
        
        % compute last point of the so made BEZIER
        Pend=lastpointNURBSPL(geometry_BEZIER(end));
        
        % add arc of an ellipse
        geometry_BEZIER(2)=makeBEZIERarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',...
            [1 2],'tilt_angle',0);
        
        % compute last point of the so made BEZIER
        Pend=lastpointNURBSPL(geometry_BEZIER(end));
        
        % add segment
        geometry_BEZIER(3)=makeBEZIERarc('segment','extrema',...
            [Pend; 0 Pend(2)]);
        
        % compute first point of the piecewise BEZIER domain
        Pinit=firstpointNURBSPL(geometry_BEZIER);
        
        % "close" the boundary with a "free" BEZIER.
        geometry_BEZIER(4)=makeBEZIERarc('free',...
            'P',[0 Pend(2); -1.2 0.3; -1.0 0.5; Pinit],'order',4);
        
        % join piecewise BEZIER
        geometry_BEZIER=joinNURBSPLarcs(geometry_BEZIER);
        
        
        
    otherwise % variable order
        domain_str1='domain defined by a disk, an ellipse, a segment';
        domain_str2=' and a free BEZIER (variable order)';
        domain_str=strcat(domain_str1,domain_str2);
        
        % add arc of a disk
        geometry_BEZIER(1)=makeBEZIERarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);
        
        % compute first point of the piecewise BEZIER domain
        Pinit=firstpointNURBSPL(geometry_BEZIER(1));
        
        % compute last point of the so made BEZIER
        Pend=lastpointNURBSPL(geometry_BEZIER(end));
        
        % add arc of an ellipse
        geometry_BEZIER(2)=makeBEZIERarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],...
            'ell_axis',[1 2], 'tilt_angle',0);
        
        % compute last point of the so made BEZIER
        Pend=lastpointNURBSPL(geometry_BEZIER(end));
        
        % add segment
        geometry_BEZIER(3)=makeBEZIERarc('segment','extrema',...
            [Pend; 0 Pend(2)]);
        
        % compute first point of the piecewise BEZIER domain
        Pinit=firstpointNURBSPL(geometry_BEZIER);
        
        % "close" the boundary with a "free" BEZIER.
        geometry_BEZIER(4)=makeBEZIERarc('free',...
            'P',[0 Pend(2); -1.9 0.3; -1.8 0.5; Pinit],'order',4);
        
        % join piecewise BEZIER
        geometry_BEZIER=joinNURBSPLarcs(geometry_BEZIER);
        
end
