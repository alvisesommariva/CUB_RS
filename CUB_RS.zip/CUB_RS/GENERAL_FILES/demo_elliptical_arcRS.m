
function demo_elliptical_arcRS

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This demo plots the arc of the disk, with center equal to "center", with
% polar angles in
%                      [angles(1) angles(2)]
% radius equal to "radius".
%
% Since it may be that "angles(1) > angles(2)" when the arc is ordered
% clockwise, the routine shows that in these instances the codes are fine.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% First version: October 31, 2021;
% Checked: November 17, 2021.
%--------------------------------------------------------------------------

% ........................... Settings  ...................................

example=1; % 1: SPLINE, 2: BEZIER, 3: NURBS.

center=[0 0];

% angles=[pi/4 -pi/3];
angles=[0 2*pi];

ell_axis=[1 2];
tilt=0;


geometry0=makeNURBSarc('elliptical_arc','center',center,...
            'angles',[0 2*pi],'ell_axis',ell_axis,'tilt',tilt);
        
% ........................... Compute arc  ................................

switch example
    case 1
        fprintf('\n \t APPROXIMATED ELLIPSE ARC BY SPLINES');
        geometry=makeSPLINEarc('elliptical_arc','center',center,...
            'angles',angles,'ell_axis',ell_axis,'tilt',tilt);

    case 2
        fprintf('\n \t APPROXIMATED ELLIPSE ARC BY BEZIER');
        geometry=makeBEZIERarc('elliptical_arc','center',center,...
            'angles',angles,'ell_axis',ell_axis,'tilt',tilt);

    case 3
        fprintf('\n \t ELLIPSE BY NURBS');
        geometry=makeNURBSarc('elliptical_arc','center',center,...
            'angles',angles,'ell_axis',ell_axis,'tilt',tilt);

end


% ........................... Plot arc & moving point .....................

fprintf('\n');
h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis equal;
plotNURBSPL(geometry0);
plotNURBSPL(geometry,'dynamic');
hold off;



% ........................ Test quality Approximant .......................

% computing approximated value
[SxN,SxD,SyN,SyD]=NURBSPL2ratsplines(geometry);

a=ell_axis(1); b=ell_axis(2);

SxN0=SxN(1); t0=SxN0.breaks; t0=t0(1);
SxN1=SxN(end); t1=SxN1.breaks; t1=t1(end);

tt=linspace(t0,t1,1000); tt=tt';
X=fnval(SxN,tt)./fnval(SxD,tt); Y=fnval(SyN,tt)./fnval(SyD,tt);

% computing exact value
X0=X-center(1); Y0=Y-center(2);
if not(tilt == 0)
    R=[cos(-tilt) -sin(-tilt); sin(-tilt) cos(-tilt)];
    XY0=[X0 Y0]*R';
else
    XY0=[X0 Y0];
end

th=angle((X-center(1))/a+i*(Y-center(2))/b);

XY=[a*cos(th) b*sin(th)];
if not(tilt == 0)
   R=[cos(tilt) -sin(tilt); sin(tilt) cos(tilt)]; 
   XY=XY*R';
end
XY=bsxfun(@plus,center,XY);

% comparison
fprintf('\n \t Max. Error curve vs ellipse: %1.3e \n',norm(XY-[X Y],inf));
