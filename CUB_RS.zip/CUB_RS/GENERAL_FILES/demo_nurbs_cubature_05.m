
function demo_nurbs_cubature_04(domain_type)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating CUBATURE:
% 1. how to define a NURBS on a composite boundary, using arcs of disks,
%    ellipses, segments, polygons and "free NURBS". The routines work on
%    piecewise NURBS of different order.
%    To this purpose see the MATLAB function "define_domain" at the
%    bottom of this demo.
% 2. how to get an algebraic cubature rule on the desired domain, via
%    "cubRS" routine.
% 3. testing the routines over random polynomials.
%
% Note: In the numerical experiments of the accompanying paper, we have
%       used
%       1. S(3): M domain, choose domain_type=11,
%       2. S(4): joining arcs of a disk, ellipse, segment, domain_type=14,
%       3. S(5): concave domain, domain_type=1.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: December 3, 2021.
%--------------------------------------------------------------------------

warning off;

% ------------------------------ Settings ---------------------------------

% Algebraic degree of precision of the cubature rule. Suggested values are
% mild, e.g. not larger than "ade=15". Typical "ade" in the applications
% are between "3" and "5".
adeV=2:2:10;

% Number of tests to determine the median cputime. We suggest to set
% "tests=10", while we do not recommend "tests=1" because it often turns
% out to provide unreliable cputimes.
tests=100;

% Cubature extraction method: the variable "extraction_type" sets how
% Tchakaloff rule is extracted.
%      1: lsqnonneg, 2: lawsonhanson, 3: LHDM 4: \
% If not declared or equal to "[]", the default is LHDM, see
% "dCATCH: a numerical package for d-variate near G-optimal Tchakaloff
% regression via fast NNLS"
% M. Dessole, F. Marcuzzi and M. Vianello
% MDPI-Mathematics 8 (2020) - Special Issue "Numerical Methods"
extraction_type=3;

% Nbox is a technical parameter for indomain routine; in doubt set 100.

Nbox=100;

% In indomain routine one must be certain that points are inside the
% domain. In our cubature needs we just wants some points in the domain.
% Consequently, if we are not fully sure that a point is in the domain, due
% to geometrical issues, we do not take it into account.

safe_mode=1;

% The variable "domain_type" set the domain taken into account. The names
% are just given to remember something of the region.
%
%       0. Disk
%       1. Lune like
%       2. Tau-like-symbol
%       3. Leaf
%       4. Chestnut
%       5. Golf club
%       6. Dino head
%       7. Tadpole.
%       8. Nose
%       9. Rough ball
%      10. L-shaped
%      11. M-shaped domain
%      12. defined by a disk, an ellipse and a segment
%      13. defined by a disk, an ellipse, a segment and a free NURBS
%          (variable order)
%      otherwise: defined by a disk, an ellipse, a segment and a free NURBS
%          (variable order)
if nargin < 1
    domain_type=9;
end









% ----------------------------- Main code ---------------------------------

%--------------------------------------------------------------------------
% 1. Make NURBS structure
%--------------------------------------------------------------------------
[geometry_NURBS,domain_str]=define_domain(domain_type);

REV=[]; logerrV=[];

% Define functions
f1=@(x,y) exp(-(x.^2+y.^2));
f2=@(x,y) (x.^2+(y-0.4).^2).^(11/2);
f3=@(x,y) (x.^2+(y-0.4).^2).^(1/2);

% Define high order rule

[inside,in_doubts,sp_xnV,sp_xdV,sp_ynV,sp_ydV,boxVx,...
    singular_points_X,singular_points_Y]=inRS([],geometry_NURBS,...
    Nbox,safe_mode);
xywL = cubRS(30,geometry_NURBS,0,Nbox,safe_mode);

xxL=xywL(:,1); yyL=xywL(:,2); wwL=xywL(:,3);
I(1)=wwL'*feval(f1,xxL,yyL);
I(2)=wwL'*feval(f2,xxL,yyL);
I(3)=wwL'*feval(f3,xxL,yyL);

for jj=1:length(adeV)

    ade=adeV(jj);

    %----------------------------------------------------------------------
    % 2. Compute algebraic cubature rule of the domain (several tests!).
    %----------------------------------------------------------------------
    xyw = cubRS(ade,geometry_NURBS,extraction_type,Nbox,safe_mode);
    xx=xyw(:,1); yy=xyw(:,2); ww=xyw(:,3);

    %----------------------------------------------------------------------
    % 3. Making tests.
    %----------------------------------------------------------------------
    I0(1)=ww'*feval(f1,xx,yy);
    I0(2)=ww'*feval(f2,xx,yy);
    I0(3)=ww'*feval(f3,xx,yy);

    RE=abs((I-I0)./I);

    %----------------------------------------------------------------------
    % 4. Statistics.
    %----------------------------------------------------------------------

    fprintf('\n \t %2.0f | %1.1e | %1.1e | %1.1e | ',ade,RE(1),RE(2),RE(3));


end

fprintf('\n \n')
















%--------------------------------------------------------------------------
% ATTACHED ROUTINES
%--------------------------------------------------------------------------

function [geometry_NURBS,domain_str]=define_domain(example)

switch example

    case 1 % M-shaped domain

        domain_str='S(3): M shaped domain';
        order=3;
        P=[-1 1; -1 0; -1 -1; -0.6 -1; -0.6 0; -0.6 0.6; 0 0; 0.6 0.6; ...
            0.6 0; 0.6 -1; 1 -1; 1 0; 1 1; 0.6 1; 0 0.4; -0.6 1; -1 1];
        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 2

        domain_str='S(4): domain defined by a disk, an ellipse, a segment';
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',[0 0],'angles',[pi/2 3*pi/2],'ell_axis',[0.5 1],...
            'tilt_angle',0);

        % add a final segment
        Pend=lastpointNURBSPL(geometry_NURBS(2));
        Pinit=firstpointNURBSPL(geometry_NURBS(1));
        geometry_NURBS(3)=makeNURBSarc('segment','vertices',[Pend; Pinit]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

    case 3 % lune-like
        domain_str='S(5): lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        knots=[0 0 0 .15 .25 .25 .5 .5 .75 .75 1 1 1];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1];
        order=3;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 4 % square/disk difference
        domain_str='domain 4';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));


        % add arc of an ellipse
        v=[0.5 0;0.5 0.5;0 0.5];
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);





    case 5 % polygon/disk union
        domain_str='domain 5';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0.25 0.25],'angles',[pi pi+pi/2],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.4 0.05; 0.5 0.25; 0.45 0.45; 0.3 0.5;0.1 0.45]; % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);





    case 6 % polygon/disk union
        domain_str='domain 6';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.25 0.2; 0.2 0.25];  % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);



    case 7 % polygon/disk union
        domain_str='domain 7';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[pi/2 0],'radius',0.25);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        v=[0.4 0.05; 0.5 0.25; 0.45 0.45; 0.3 0.5;0.1 0.45]; % polyg. vert.
        vertices=[Pend; v; Pinit];
        geometry_NURBS(2)=makeNURBSarc('polygonal_arc',...
            'vertices',vertices);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);


    case 8 % polygon/disk union
        domain_str='domain 8: square';

        v=[0 0; 1 0; 1 1; 0 1; 0 0];
        geometry_NURBS(1)=makeNURBSarc('polygonal_arc',...
            'vertices',v);


    case 9 % polygon/disk union
        domain_str='domain 9: union of rectangles';

        % add arc of an ellipse
        v=[0 0; 1 0; 1 1; 2 1; 2 2; 1 2; 1 1.5; 0 1.5; 0 1.25; -0.5 1.25; ...
            -0.5 0; 0 0];
        geometry_NURBS(1)=makeNURBSarc('polygonal_arc',...
            'vertices',v);










    case 10
        domain_str='domain 10: square';
        P=[0 0; 1 0; 1 1; 0 1; 0 0];
        geometry_NURBS=makeNURBSarc('polygonal_arc','vertices',P);

    case 11 % circle
        domain_str='domain 11: circle';
        geometry_NURBS=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 2*pi],'radius',1);

    case 12 % lune-like
        domain_str='domain 12: lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        order=3;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free',...
            'P',P,'knots',knots,'weights',w,'order',order);


    case 13 % tau-like-symbol
        domain_str='domain 13: tau-like-symbol';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5;  ...
            0.2 -0.45; -0.4 -0.4; 0 -1; 1 -1;  1 0];
        order=3;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 14 % cubic-domain
        domain_str='domain 14: cubic-domain: leaf';
        P=[1 0; 1 1; 0 1; -1 1; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);



    case 15 % cubic-domain: nut
        domain_str='domain 15: cubic-domain: slanted nut';
        P=[1 0; 1 1; 0 1; -1 0.6; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 16 % cubic-domain: slanted boomerang
        domain_str='domain 16: cubic-domain: golf club';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.4 0.6; 0 0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c/2 1 c/4 1 c/4 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 17 % cubic-domain: nut
        domain_str='domain 17: cubic-domain: dino head';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 -1; 0 0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c/2 1 c/4 1 c/4 1 1 c 1];


        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 18 % cubic-domain: slanted boomerang
        domain_str='domain 18: cubic-domain: tadpole';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.4 0.6; 0 -0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 1 1 1 1 1 1 1 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 19 % cubic-domain: nut
        domain_str='domain 19: cubic-domain: nose';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 0.5; 1 -1;  1 0];
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 5 5 5 5 5 5 5 1];


        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 20 % rough-ball
        domain_str='domain 20: rough ball';
        order=3;
        sidesL=20;
        t=linspace(0,2*pi,sidesL); t=t';
        P=[cos(t) sin(t)]; P=[P(1:end-1,:); P(1,:)];
        knots_mid=linspace(0.1,0.9,sidesL-order);
        knots=[zeros(1,order) knots_mid ones(1,order)];
        M=size(P,1);
        % w=rand(1,M);
        w=[ 8.258169774895474e-01
            5.383424352600571e-01
            9.961347166268855e-01
            7.817552875318368e-02
            4.426782697754463e-01
            1.066527701805844e-01
            9.618980808550537e-01
            4.634224134067444e-03
            7.749104647115024e-01
            8.173032206534330e-01
            8.686947053635097e-01
            8.443584551091032e-02
            3.997826490988965e-01
            2.598704028506542e-01
            8.000684802243075e-01
            4.314138274635446e-01
            9.106475944295229e-01
            1.818470283028525e-01
            2.638029165219901e-01
            1.455389803847170e-01]';

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 21 % L-shaped domain

        domain_str='domain 21: L shaped domain';
        P=[-1 1; -1 -1; 1 -1; 1 -0.6; -0.6 -0.6; -0.6 1; -1 1]; % 7 points
        order=3;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        w=[0.2 5 10 10 100 5 0.2];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 22 % variable order
        domain_str='domain 22, defined by a disk, an ellipse and a segment';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],...
            'ell_axis',[1 2],'tilt_angle',0);

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(2));

        % "close" the boundary with a segment
        geometry_NURBS(3)=makeNURBSarc('segment','extrema',...
            [Pend; Pinit]);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);



    case 23 % variable order

        domain_str1='domain 23, defined by a disk, an ellipse, a segment';
        domain_str2=' and a free NURBS (variable order)';
        domain_str=strcat(domain_str1,domain_str2);

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(end));

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(end));

        % add segment
        geometry_NURBS(3)=makeNURBSarc('segment','extrema',[Pend; 0 Pend(2)]);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS);

        % "close" the boundary with a "free" NURBS.
        geometry_NURBS(4)=makeNURBSarc('free',...
            'P',[0 Pend(2); -1.9 0.3; -1.8 0.5; Pinit],...
            'knots',[0 0 0 0 1 1 1 1],'weights',[1 1 2 1],'order',4);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);

    case 24 % variable order

        domain_str='domain 24, defined by a disk, an ellipse, a segment';
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',[0 0],'angles',[pi/2 3*pi/2],'ell_axis',[0.5 1],...
            'tilt_angle',0);

        % add a final segment
        Pend=lastpointNURBSPL(geometry_NURBS(2));
        Pinit=firstpointNURBSPL(geometry_NURBS(1));
        geometry_NURBS(3)=makeNURBSarc('segment','vertices',[Pend; Pinit]);

        % join pieces
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);


    case 25 % cubic-domain: nut
        domain_str='domain 25: 15-inverse cubic-domain: slanted nut';
        P=[1 0; 1 1; 0 1; -1 0.6; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        P=P(:,[2 1]);
        order=4;
        L=size(P,1); tt=linspace(0,1,L-order+2);
        ttinit=zeros(1,order); ttmid=tt(2:end-1);  ttfin=ones(1,order);
        knots=[ttinit ttmid ttfin];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);



end











%==========================================================================
% lineint
%==========================================================================

function xyw = lineint(ade,sp_xnV,sp_xdV,sp_ynV,sp_ydV)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This routine computes weights and nodes for the line integral on Jordan
% domains whose boundary is given counterclockwise by the rational splines.
% The formula is exact on bivariate polynomials up to algebraic degree of
% precision "ade".
%--------------------------------------------------------------------------
% INPUT:
% ade: polynomial degree to be integrated, via its x-primitive, on the
%    domain.
% sp_xn,sp_xd,sp_yn,sp_yd: arrays of spline structures;
%    (Sx(i),Sy(i)) is the i-th arc the arcs must be counterclockwise
%    concatenated forming a Jordan curve
%         Sx(i).breaks(end)=Sx(i+1).breaks(1),
%         Sy(i).breaks(end)=Sy(i+1).breaks(1)
%         i=1,...,end, with end+1:=1
%    with "Sx=sp_xn/sp_xd", "Sy=sp_yn/sp_yd".
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% xyw: 3-column array of nodes coords (cols 1-2) and weights (col 3)
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% built: March 2019
% check: November 12, 2021
%--------------------------------------------------------------------------


LL=length(sp_xnV);
xyw=[];

% analysing k-th block
for kk=1:LL

    % splines that define locally the boundary
    sp_xn=sp_xnV(kk); sp_xd=sp_xdV(kk); % x(t)=sp_xn(t)/sp_xd(t)
    sp_yn=sp_ynV(kk); sp_yd=sp_ydV(kk); % y(t)=sp_yn(t)/sp_yd(t)

    intv=sp_xn.breaks;

    % analysing i-th block subinterval
    for i=1:length(intv)-1

        p1=sp_xn.coefs(i,:); p2=sp_yn.coefs(i,:);
        q1=sp_xd.coefs(i,:); q2=sp_yd.coefs(i,:);

        ord_RSnum=length(p1);
        a=intv(i); b=intv(i+1);

        % .............. determining line-integral formula  ...............

        % appropriate Gauss-Legendre rule
        if (norm(q1,1) == 1 & q1(end) == 1) & ...
                (norm(q2,1) == 1 & q2(end) == 1)
            % polynomial type (ord_RSnum=ord_RSden);
            xw=gaussian_quadrature(ord_RSnum,a,b,ade);
            % xw=rational_quadrature(ord_RSnum,a,b,ade);
        else
            % rational type (assuming ord_RSnum=ord_RSden)
            xw=rational_quadrature(ord_RSnum,a,b,ade);
        end

        t=xw(:,1); w=xw(:,2); tL=t-a;

        % determination of the line formula nodes and weights

        p1_tL=polyval(p1,tL); q1_tL=polyval(q1,tL);
        p2_tL=polyval(p2,tL); q2_tL=polyval(q2,tL);

        % A. nodes.
        XL=p1_tL./q1_tL; YL=p2_tL./q2_tL;

        % B. weights.
        p1L=length(p1);
        if p1L == 1
            p2_diff=0;
        else
            derV=p1L-1:-1:1; p2_diff=p2(1:end-1).*derV;
        end

        q1L=length(q1);
        if q1L == 1
            q2_diff=0;
        else
            derV=q1L-1:-1:1; q2_diff=q2(1:end-1).*derV;
        end

        p2_diff_tL=polyval(p2_diff,tL); q2_diff_tL=polyval(q2_diff,tL);

        y1_term=(p2_diff_tL.*q2_tL-p2_tL.*q2_diff_tL)./q2_tL.^2;
        WL=w.*y1_term;

        % C. Assembly the rule.
        xyw=[xyw; XL YL WL];

    end

end









%==========================================================================
% intcvand
%==========================================================================

function intV = intcvand(n,pts,bbox)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This subroutine computes by recurrence an x-primitive
% Chebyshev-Vandermonde matrix on a 2d arbitrarily located mesh, in a
% total-degree product Chebyshev basis of a given rectangle.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% n: polynomial degree
% pts: 2-column array of mesh point coordinates
% bbox: [bbox(1),bbox(2)] x [bbox(3),bbox(4)] bounding box for the mesh
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% intV: x-primitive of the Chebyshev-Vandermonde matrix
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% built: March 2019
% check: November 12, 2021
%--------------------------------------------------------------------------

% default rectangle containing the mesh if not passed

if isempty(bbox)
    bbox=[min(pts(:,1)) max(pts(:,1)) min(pts(:,2)) max(pts(:,2))];
end

a=bbox(1);b=bbox(2);c=bbox(3);d=bbox(4);

Vx=chebpolys(n+1,(2*pts(:,1)-b-a)/(b-a));
Vy=chebpolys(n,(2*pts(:,2)-d-c)/(d-c));

k=0;
for i=0:n
    for j=0:n-i
        k=k+1;

        if i==0
            intV(:,k)=pts(:,1).*Vy(:,j+1);
        end

        if i==1
            intV(:,k)=0.25*(b-a)*(((2*pts(:,1)-b-a)/(b-a)).^2).*Vy(:,j+1);
        end

        if i>1
            intV(:,k)=0.25*(b-a)*(Vx(:,i+2).*Vy(:,j+1)/(i+1)-...
                Vx(:,i).*Vy(:,j+1)/(i-1));
        end

    end
end





%==========================================================================
% rational_quadrature
%==========================================================================

function xw=rational_quadrature(ord_RS,a,b,ade)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This routine computes a quadrature rule on an arc of Jordan domains
% whose boundary is given counterclockwise by the rational splines.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% sp_xd_coefs,sp_yd_coefs: coefficients in [a,b] of the denominators
%     defining x(t), y(t); it is supposed that in the interval [a,b] the
%     nurbs is actually a rational function (i.e. quotient of 2
%     polynomials);
% a,b: two successive break points of the splines defining "Sx", "Sy" (i.e.
%    the parametric rational splines defining the domain boundary.
% ade: algebraic degree of exactness of the rule.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% xw: matrix N x 2, whose first column are the nodes "t", while the second
%     are the weights "w".
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% First version: October 31, 2021;
% Checked: November 7, 2021.
%--------------------------------------------------------------------------
% NOTE:
%--------------------------------------------------------------------------
% Though we have also used "rfejer routine", we do not suggest its use
% since numerical tests do not seem to provide always good results.
%--------------------------------------------------------------------------

A=(a+b)/2; B=(b-a)/2;

xw=legendre_rules(10000);


xx=A+B*xw(:,1); ww=xw(:,2); ww=B*ww; xw=[xx ww];









%==========================================================================
% rational_quadrature
%==========================================================================

function xw=gaussian_quadrature(ord_S,a,b,ade)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This routine computes a quadrature rule on an arc of Jordan domains
% whose boundary is given counterclockwise by the rational splines.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% sp_xd_coefs,sp_yd_coefs: coefficients in [a,b] of the denominators
%     defining x(t), y(t); it is supposed that in the interval [a,b] the
%     nurbs is actually a rational function (i.e. quotient of 2
%     polynomials);
% a,b: two successive break points of the splines defining "Sx", "Sy" (i.e.
%    the parametric rational splines defining the domain boundary.
% ade: algebraic degree of exactness of the rule.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% xw: matrix N x 2, whose first column are the nodes "t", while the second
%     are the weights "w".
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% First version: October 31, 2021;
% Checked: November 7, 2021.
%--------------------------------------------------------------------------
% NOTE:
%--------------------------------------------------------------------------
% Though we have also used "rfejer routine", we do not suggest its use
% since numerical tests do not seem to provide always good results.
%--------------------------------------------------------------------------

A=(a+b)/2; B=(b-a)/2;
k=ceil(((ord_S-1)*(ade+2))/2)+2;
method=0;
xw=legendre_rules(k);


t=xw(:,1); w=xw(:,2);

xx=A+B*xw(:,1); ww=xw(:,2); ww=B*ww; xw=[xx ww];


%==========================================================================
% plot_errors
%==========================================================================

function plot_errors(ii,n,reV,log_re)

if ii <= 5
    switch ii
        case 1
            plotstr='m+'; linestr='m-';
        case 2
            plotstr='g+'; linestr='g-';
        case 3
            plotstr='r+'; linestr='r-';
        case 4
            plotstr='b+'; linestr='b-';
        case 5
            plotstr='c+'; linestr='b-';
        otherwise
            plotstr='k.'; linestr='w.';
    end
    %     semilogy(1:number_experiments,reV,plotstr); hold on;
    %     semilogy(1:number_experiments,log_reV(ii)*ones(1,number_experiments),...
    %         linestr,'Linewidth',3);
    semilogy(n*ones(size(reV)),reV,plotstr,'LineWidth',2); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',30,'MarkerEdgeColor','k',...
        'LineWidth',2);
else
    semilogy(n*ones(size(reV)),reV,'color',rand(1,3)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',29,'MarkerEdgeColor','k');
end



