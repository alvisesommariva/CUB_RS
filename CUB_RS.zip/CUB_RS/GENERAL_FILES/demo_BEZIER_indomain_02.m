
function demo_BEZIER_indomain_02(domain_type)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo on 
% Demo on INDOMAIN procedure.
% 1. how to define a BEZIER composite boundary, using arcs of a disk or of
%    an ellipse, polygonal arcs as well as "free Bezier", i.e. a Bezier 
%    arcs defined by control points and order (see the subroutine 
%    "define_domain" at about line 180).
% 2. how to define an equispaced pointset on the domain via "ptsRS".
% 3. how to perform indomain analysis via "inRS".
% 4. how to plot the domain by "plotNURBSPL".
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.

%--------------------------------------------------------------------------

% ------------------------------ Settings ---------------------------------

% Number of tests to determine the median cputime. We suggest to set
% "tests=10", while we do not recommend "tests=1" because it often turns
% out to provide unreliable cputimes.
% We remind that cputime may vary with the computer.
tests=10;


% Nbox is a technical parameter for indomain routine; in doubt set 100.
Nbox=1;

% In indomain routine one must be certain that points are inside the
% domain. In our cubature needs we just wants some points in the domain.
% Consequently, if we are not fully sure that a point is in the domain, due
% to geometrical issues, we do not take it into account.
safe_mode=1;

% We determine a tensorial grid on the smaller rectangle with sides
% parallel to the axis, containing all the control points.
% The grid has "Ngrid" points per dimension. For instance, "Ngrid=100"
% provides a grid with "100 * 100=10000" points.
Ngrid=70;

% The variable "domain_type" set the domain taken into account. The
% invented names are just given to remember something of the region.
%
%       0. Disk
%       1. Lune like
%       2. Tau-like-symbol
%       3. Quadrangloid
%       4. Curved trapezoid
%       5. Weird eta
%       6. Weird eta 2
%       7. Weird eta 3
%       8. Weird eta skinny
%       9. Rough ball
%      10. L-shaped
%      11. M-shaped domain
%      12. defined by a disk, an ellipse and a segment
%      13. defined by a disk, an ellipse, a segment and a free BEZIER
%          (variable order)
%      otherwise: defined by a disk, an ellipse, a segment and a free BEZIER
%          (variable order)

if nargin < 1, domain_type=3; end






% ----------------------------- Main code ---------------------------------

%--------------------------------------------------------------------------
% 1. Make BEZIER structure
%--------------------------------------------------------------------------

[geometry_BEZIER,domain_str]=define_domain(domain_type);

%--------------------------------------------------------------------------
% 2. Generate test points (tensorial grid on a rectangle containing domain)
%--------------------------------------------------------------------------
pts=ptsRS(geometry_BEZIER,Ngrid);

%--------------------------------------------------------------------------
% 3. Indomain (several cputime tests!).
%--------------------------------------------------------------------------
fprintf('\n \t ');
for k=1:tests
    tic;
    [in,in_doubts,sp_xnV,sp_xdV,sp_ynV,sp_ydV,boxVxy,turn_pts_X, ...
        turn_pts_Y]=inRS(pts,geometry_BEZIER,Nbox,safe_mode);
    cpus(k)=toc;
end


%--------------------------------------------------------------------------
% 4. Plot domain and control points polygon.
%--------------------------------------------------------------------------

[SxNV,SxDV,SyNV,SyDV]=NURBSPL2ratsplines(geometry_BEZIER,'B-');

h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis square;
% plot piecewise SPLINE curve
plotNURBSPL(geometry_BEZIER);

% Plot points inside the domain
iok=find(in == 1);
Xin=pts(iok,1); Yin=pts(iok,2);
plot(Xin,Yin,'go','MarkerEdgeColor','g',...
    'MarkerFaceColor','g',...
    'MarkerSize',4);


% Plot points not inside the domain
iko=find(not(in == 1));
Xo=pts(iko,1); Yo=pts(iko,2);
plot(Xo,Yo,'ro','MarkerEdgeColor','r',...
    'MarkerFaceColor','r',...
    'MarkerSize',4);

% Title
titlesrt=strcat('Indomain test:  ',num2str(size(pts,1)), ' points');
title(titlesrt);

hold off;





h=figure(2);
f2=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f2,clf(2);end
figure(2)
hold on;
axis equal;


% A. plot SPLINE curve (black)
plotNURBSPL(geometry_BEZIER);

% B. Plot monotone boxes
LB=size(boxVxy,1);
for k=1:LB
    a=boxVxy(k,1); b=boxVxy(k,2); c=boxVxy(k,3); d=boxVxy(k,4);
    plot([a b b a a],[c c d d c],'c-','LineWidth',3);
end

% C. plot turning points
plot(turn_pts_X(:,1),turn_pts_X(:,2),'bd',...
    'MarkerEdgeColor','b',...
    'MarkerFaceColor','b',...
    'MarkerSize',10);

plot(turn_pts_Y(:,1),turn_pts_Y(:,2),'md',...
    'MarkerEdgeColor','m',...
    'MarkerFaceColor','m',...
    'MarkerSize',10);

hold off;


%--------------------------------------------------------------------------
% 5. Display statistics.
%--------------------------------------------------------------------------

fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t          BEZIER INDOMAIN TESTS \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t DOMAIN: '); disp(domain_str);
fprintf('\n');
fprintf('\n \t # TRIAL POINTS               : %6.0f',size(pts,1));
fprintf('\n \t # TRIAL POINTS               : %6.0f',length(iko));
fprintf('\n \t MEDIAN CPUTIME               : %1.3e',median(cpus));
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             PLOT DESCRIPTION \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t FIGURE 1   ');
fprintf('\n ');
fprintf('\n \t * Green dots: points inside the domain.   \n \t');
fprintf('\n \t * Red dots: points not inside the domain.   \n \t');
% fprintf('\n \t * Cyan squares: control points.   \n \t');
% fprintf('\n \t * Black dotted lines: control polygon.   \n \t');
% fprintf('\n \t * Magenta diamonds: boundary singular points.   \n \t');
fprintf('\n \t ------------------------------------------- \n');
fprintf('\n \t FIGURE 2   ');
fprintf('\n ');
fprintf('\n \t * Cyan squares: monotone boxes (even "small")  \n \t');
% fprintf('\n \t * Black dotted lines: control polygon.   \n \t');

fprintf('\n \t * Blue diamonds: bound. sing. points X dir.   \n \t');
fprintf('\n \t * Magenta diamonds: bound. sing. points Y dir.    \n \t');
fprintf('\n \t ------------------------------------------- \n');










%--------------------------------------------------------------------------
% ATTACHED ROUTINES
%--------------------------------------------------------------------------

function [geometry_BEZIER,domain_str]=define_domain(example)

switch example
    
    case 0 % circle
        domain_str='circle';
        geometry_BEZIER=makeBEZIERarc('disk_arc','center',[0 0],...
            'angles',[0 2*pi],'radius',1);
        
        
    case 1 % lune-like
        domain_str='lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        order=4;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
        
    case 2
        domain_str='Tau-like-symbol';
        P=[1 0; 0.8 0.1; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5;  ...
            0.2 -0.45; -0.4 -0.4; 0 -1; 0.5 -1; 1 -1;  1 0];
        order=3;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
        
    case 3
        domain_str='Leaf-like';
        P=[1 0; 1 1; 0 1; -1 1; -1 0; -1 -1; 0 -1; 1 -1; 1 -0.5; 1 0];
        order=4;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
        
        
    case 4
        domain_str='Curved trapezoid: glasses lens';
        P=[1 0; 1 1; 0 1; -1 0.6; -1 0; -1 -1; 0 -1; 1 -1; 1 -0.7; 1 0];
        order=4;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
        
    case 5
        domain_str='Weird eta';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.1 0.1; ...
            0 0.5; 1 -1;  1 -0.7;   1 0];
        order=4;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
    case 6
        domain_str='Weird eta 2';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 -1; 0 0.5; ...
            1 -1; 1 -0.7;  1 0];
        order=6;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
        
    case 7
        domain_str='Weird eta 3';
        P=[1 0; 1 1; 0 1;  -1 0; -1 -0.7; -1 -1; -0.4 -0.2; 0 -0.5; ...
            1 -1;  1 0];
        order=4;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
    case 8
        domain_str='Weird eta skinny';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 0.5; 1 -1; 0.5 0.2;1 0];
        order=4;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
    case 9 % rough-ball
        domain_str='rough ball';
        sidesL=21;
        t=linspace(0,2*pi,sidesL); t=t';
        P=[cos(t) sin(t)]; P=[P(1:end-1,:); P(1,:)];
        order=5;
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
    case 10 % L-shaped domain
        
        domain_str='L shaped domain';
        P=[-1 1; -1 0; -1 -0.5; -1 -1; 1 -1; 1 -0.6; -0.6 -0.6; ...
            -0.6 1; -1 1]; % 7 points
        order=3;
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
    case 11 % M-shaped domain
        
        domain_str='M shaped domain';
        order=3;
        P=[-1 1; -1 0; -1 -1; -0.6 -1; -0.6 0; -0.6 0.6; 0 0; 0.6 0.6; ...
            0.6 0; 0.6 0.5; 0.6 -1;  1 -1; 1 0; 1 1; 0.88 1.07; 0.6 1; ...
            0 0.4; -0.6 1; -0.76 1.03; -0.88 1.07; -1 1];
        
        geometry_BEZIER=makeBEZIERarc('free','P',P,'order',order);
        
    case 12 % variable order
        domain_str='domain 12, defined by a disk, an ellipse and a segment';
        
        
        % add arc of a disk
        geometry_BEZIER(1)=makeBEZIERarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);
        
        % compute first point of the piecewise BEZIER domain
        Pinit=firstpointNURBSPL(geometry_BEZIER(1));
        
        % compute last point of the so made BEZIER
        Pend=lastpointNURBSPL(geometry_BEZIER(1));
        
        % add arc of an ellipse
        geometry_BEZIER(2)=makeBEZIERarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],...
            'ell_axis',[1 2],'tilt_angle',0);
        
        % compute last point of the so made BEZIER
        Pend=lastpointNURBSPL(geometry_BEZIER(2));
        
        % "close" the boundary with a segment
        geometry_BEZIER(3)=makeBEZIERarc('segment','extrema',...
            [Pend; Pinit]);
        
        % join piecewise BEZIER
        geometry_BEZIER=joinNURBSPLarcs(geometry_BEZIER);
        
    case 13 % variable order
        domain_str1='domain 13, defined by a disk, an ellipse, a segment';
        domain_str2=' and a free BEZIER (variable order)';
        domain_str=strcat(domain_str1,domain_str2);
        
        % add arc of a disk
        geometry_BEZIER(1)=makeBEZIERarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);
        
        % compute first point of the piecewise BEZIER domain
        Pinit=firstpointNURBSPL(geometry_BEZIER(1));
        
        % compute last point of the so made BEZIER
        Pend=lastpointNURBSPL(geometry_BEZIER(end));
        
        % add arc of an ellipse
        geometry_BEZIER(2)=makeBEZIERarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',...
            [1 2],'tilt_angle',0);
        
        % compute last point of the so made BEZIER
        Pend=lastpointNURBSPL(geometry_BEZIER(end));
        
        % add segment
        geometry_BEZIER(3)=makeBEZIERarc('segment','extrema',...
            [Pend; 0 Pend(2)]);
        
        % compute first point of the piecewise BEZIER domain
        Pinit=firstpointNURBSPL(geometry_BEZIER);
        
        % "close" the boundary with a "free" BEZIER.
        geometry_BEZIER(4)=makeBEZIERarc('free',...
            'P',[0 Pend(2); -1.2 0.3; -1.0 0.5; Pinit],'order',4);
        
        % join piecewise BEZIER
        geometry_BEZIER=joinNURBSPLarcs(geometry_BEZIER);
        
        
        
    otherwise % variable order
        domain_str1='domain defined by a disk, an ellipse, a segment';
        domain_str2=' and a free BEZIER (variable order)';
        domain_str=strcat(domain_str1,domain_str2);
        
        % add arc of a disk
        geometry_BEZIER(1)=makeBEZIERarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);
        
        % compute first point of the piecewise BEZIER domain
        Pinit=firstpointNURBSPL(geometry_BEZIER(1));
        
        % compute last point of the so made BEZIER
        Pend=lastpointNURBSPL(geometry_BEZIER(end));
        
        % add arc of an ellipse
        geometry_BEZIER(2)=makeBEZIERarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],...
            'ell_axis',[1 2], 'tilt_angle',0);
        
        % compute last point of the so made BEZIER
        Pend=lastpointNURBSPL(geometry_BEZIER(end));
        
        % add segment
        geometry_BEZIER(3)=makeBEZIERarc('segment','extrema',...
            [Pend; 0 Pend(2)]);
        
        % compute first point of the piecewise BEZIER domain
        Pinit=firstpointNURBSPL(geometry_BEZIER);
        
        % "close" the boundary with a "free" BEZIER.
        geometry_BEZIER(4)=makeBEZIERarc('free',...
            'P',[0 Pend(2); -1.9 0.3; -1.8 0.5; Pinit],'order',4);
        
        % join piecewise BEZIER
        geometry_BEZIER=joinNURBSPLarcs(geometry_BEZIER);
        
end




