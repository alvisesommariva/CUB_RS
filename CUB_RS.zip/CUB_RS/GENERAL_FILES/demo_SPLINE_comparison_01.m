
function demo_SPLINE_comparison_01(domain_type)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating:
% 1. how to define a SPLINE on a composite boundary, using arcs of disks,
%    ellipses, segments, polygons and "free SPLINE". The routines work on
%    piecewise SPLINE of different order.
%    To this purpose see the MATLAB function "define_domain" at the
%    bottom of this demo.
% 2. how to call the indomain routine "cubRS" with a certain algebraic 
%    degree of precision ADE.
% 3. comparison with the old spline routine "cubS", on the computation of
%    random polynomials of total degree at most ADE.
% 4. plot figure and nodes of the two set of nodes obtained with "cubRS"
%    and "cubS".
% 5. cubature on random polynomials: absolute error w.r.t. the two
%    routines, e.g. a result equal to 0 means that the two routines provide
%    exactly the same results.
%--------------------------------------------------------------------------


% ------------------------------ Settings ---------------------------------

% Algebraic degree of precision of the cubature rule. Suggested values are
% mild, e.g. not larger than "ade=15". Typical "ade" in the applications
% are between "3" and "5".
ade=5;

% Number of tests to determine the median cputime. We suggest to set
% "tests=10", while we do not recommend "tests=1" because it often turns
% out to provide unreliable cputimes.
% We remind that cputime may vary with the computer.
tests=10;

% In indomain routine one must be certain that points are inside the
% domain. In our cubature needs we just wants some points in the domain.
% Consequently, if we are not fully sure that a point is in the domain, due
% to geometrical issues, we do not take it into account.
safe_mode=1;

% The variable "domain_type" set the domain taken into account. The
% invented names are just given to remember something of the region.
%
%       0. Disk
%       1. Lune like
%       2. Tau-like-symbol
%       3. Quadrangloid
%       4. Curved trapezoid
%       5. Weird shape 1
%       6. Weird shape 2
%       7. Weird shape 3
%       8. Weird shape 4
%       9. Rough ball
%      10. L-shaped
%      11. M-shaped domain
%      12. defined by a disk, an ellipse and a segment
%      13. defined by a disk, an ellipse, a segment and a free SPLINE
%          (variable order)
%      otherwise: defined by a disk, an ellipse, a segment and a free SPLINE
%          (variable order)

if nargin < 1
    domain_type=10;
end

% extraction_type: it sets how Tchakaloff rule is extracted
%      1: lsqnonneg, 2: lawsonhanson, 3: LHDM 4: \
%      This variable is not mandatory. If not declared or equal to "[]",
%      the default is LHDM.

extraction_type=3;



% ----------------------------- Main code ---------------------------------

%--------------------------------------------------------------------------
% 1. Make SPLINE structure
%--------------------------------------------------------------------------

[geometry_SPLINE,domain_str]=define_domain(domain_type);


%--------------------------------------------------------------------------
% 2. Generate test points (tensorial grid on a rectangle containing domain)
%--------------------------------------------------------------------------

% SPLINE control points.
P=[];
for k=1:length(geometry_SPLINE)
    geometry_SPLINEL=geometry_SPLINE(k); PL=geometry_SPLINEL.P; P=[P; PL];
end


%--------------------------------------------------------------------------
% 3. Indomain (several cputime tests!).
%--------------------------------------------------------------------------
fprintf('\n \t ');

% 2021 code
for k=1:tests
    tic;
    [xyw,res,Z,Zin,cmom,bbox,itlevel] = cubRS(ade,geometry_SPLINE);
    cpus_21(k)=toc;
end

% 2020 code
for k=1:tests
    tic;
    [Sx,sp_xdV,Sy,sp_ydV]=NURBSPL2ratsplines(geometry_SPLINE,'PP');
    [xyw0,res0,Z0,Zin0,cmom0,bbox] = cubS(ade,Sx,Sy,extraction_type);
    cpus_20(k)=toc;
end

deltaVmaxRE=random_polynomials_tests(ade,xyw,xyw0,tests);

% Note: "cmom" and "cmom0" are moments of tens. Cheb. polynomial on
% rectangles that are almost equal but not exactly the same (they depend on
% the integral rule on the line). So moments "cmom0" and "cmom" may just be
% similar without being numerically equal.

%--------------------------------------------------------------------------
% 4. Display statistics.
%--------------------------------------------------------------------------

fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t          SPLINE INDOMAIN TESTS \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t DOMAIN: '); disp(domain_str);
fprintf('\n');
fprintf('\n \t ALGEBRAIC DEGREE OF PRECISION: %3.0f',ade);
fprintf('\n');
fprintf('\n \t * TRIALS    2020 : %6.0f',size(Z0,1));
fprintf('\n \t * TRIALS    2021 : %6.0f',size(Z,1));
fprintf('\n \t * TRIALS IN 2020 : %6.0f',size(Zin0,1));
fprintf(['\n \t' ...
    ' * TRIALS IN 2021 : %6.0f'],size(Zin,1));
fprintf('\n');
if tests > 2 % FIRST TRIAL MAY BE WRONG.
    fprintf('\n \t * CPU MEDIAN 2021: %1.5g',median(cpus_21(2:end)))
    fprintf('\n \t * CPU MEDIAN 2020: %1.5g',median(cpus_20(2:end)));
    fprintf('\n \t * CPU RATIO 20-20: %1.5g',median(cpus_20(2:end))...
        /median(cpus_21(2:end)));
else
    fprintf('\n \t * CPU MEDIAN 2021: %1.5g',median(cpus_21(1)))
    fprintf('\n \t * CPU MEDIAN 2020: %1.5g',median(cpus_20(1)));
end
fprintf('\n');
fprintf('\n \t * Mom. match 2020: %1.3e',res0);
fprintf('\n \t * Mom. match 2021: %1.3e',res);
fprintf('\n');
fprintf('\n \t * Random poly. AE: %1.3e',deltaVmaxRE);
fprintf('\n \n');



%--------------------------------------------------------------------------
% 5. Plot domain and control points polygon.
%--------------------------------------------------------------------------

[SxNV,SxDV,SyNV,SyDV]=NURBSPL2ratsplines(geometry_SPLINE,'B-');

h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis equal;

title('Rule 2021');

% A. plot SPLINE curve (black)
plotNURBSPL(geometry_SPLINE);

% B. plot nodes.

plot(Z(:,1),Z(:,2),'r*','MarkerEdgeColor','r',...
    'MarkerFaceColor','r','MarkerSize',4);

plot(Zin(:,1),Zin(:,2),'g*','MarkerEdgeColor','g',...
    'MarkerFaceColor','g','MarkerSize',4);

plot(xyw(:,1),xyw(:,2),'co','MarkerEdgeColor','k',...
    'MarkerFaceColor','c','MarkerSize',10);

hold off;


h=figure(2);
f2=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f2,clf(2);end
figure(2)
hold on;
axis equal;

title('Rule 2020');

% A. plot SPLINE curve (black)
plotNURBSPL(geometry_SPLINE);

% B. plot nodes.

plot(Z0(:,1),Z0(:,2),'r*','MarkerEdgeColor','r',...
    'MarkerFaceColor','r','MarkerSize',4);

plot(Zin0(:,1),Zin0(:,2),'g*','MarkerEdgeColor','g',...
    'MarkerFaceColor','g','MarkerSize',4);

plot(xyw0(:,1),xyw0(:,2),'mo','MarkerEdgeColor','k',...
    'MarkerFaceColor','m','MarkerSize',10);

hold off;






fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             PLOT DESCRIPTION \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t ... FIGURE 1 ...  \n \t');
fprintf('\n \t * Green dots: points inside the domain.   \n \t');
fprintf('\n \t * Red dots: points not inside the domain.   \n \t');
fprintf('\n \t * Cyan dots: cubature nodes.   \n \t');
fprintf('\n \n \t ... FIGURE 2 ...  \n \t');
fprintf('\n \t * Green dots: points inside the domain.   \n \t');
fprintf('\n \t * Red dots: points not inside the domain.   \n \t');
fprintf('\n \t * Magenta dots: cubature nodes.   \n \t');
fprintf('\n \t ------------------------------------------- \n');








%--------------------------------------------------------------------------
% ATTACHED ROUTINES
%--------------------------------------------------------------------------
function [geometry_SPLINE,domain_str]=define_domain(example)

switch example

    case 0 % circle
        domain_str='circle';
        geometry_SPLINE=makeSPLINEarc('disk_arc','center',[0 0],...
            'angles',[0 2*pi],'radius',1);


    case 1 % lune-like
        domain_str='lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        order=3;

        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);


    case 2
        domain_str='Tau-like-symbol';
        P=[1 0; 0.8 0.1; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5;  ...
            0.2 -0.45; -0.4 -0.4; 0 -1; 1 -1;  1 0];
        order=3;

        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);


    case 3
        domain_str='Quadrangloid';
        P=[1 0; 1 1; 0 1; -1 1; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        order=4;

        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);



    case 4
        domain_str='Curved trapezoid';
        P=[1 0; 1 1; 0 1; -1 0.6; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        order=4;

        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);


    case 5
        domain_str='Weird shape 1';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.1 0.1; 0 0.5; 1 -1;  1 0];
        order=4;

        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);

    case 6
        domain_str='Weird shape 2';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 -1; 0 0.5; 1 -1;  1 0];
        order=4;

        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);


    case 7
        domain_str='Weird shape 3';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.4 0.6; 0 -0.5; 1 -1;  1 0];
        order=4;

        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);

    case 8
        domain_str='Weird shape 4';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 0.5; 1 -1;  1 0];
        order=4;

        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);

    case 9 % rough-ball
        domain_str='rough ball';
        sidesL=20;
        t=linspace(0,2*pi,sidesL); t=t';
        P=[cos(t) sin(t)]; P=[P(1:end-1,:); P(1,:)];
        order=3;
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);

    case 10 % L-shaped domain

        domain_str='L-shaped domain';
        P=[-1 1; -1 -1; 1 -1; 1 -0.6; -0.6 -0.6; -0.6 1; -1 1]; % 7 points
        order=3;

        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);

    case 11 % M-shaped domain

        domain_str='M-shaped domain';
        order=3;
        P=[-1 1; -1 0; -1 -1; -0.6 -1; -0.6 0; -0.6 0.6; 0 0; 0.6 0.6; ...
            0.6 0; 0.6 -1; 1 -1; 1 0; 1 1; 0.6 1; 0 0.4; -0.6 1; -1 1];

        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);

    case 12 % variable order
        domain_str='domain 12, defined by a disk, an ellipse and a segment';


        % add arc of a disk
        geometry_SPLINE(1)=makeSPLINEarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE(1));

        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(1));

        % add arc of an ellipse
        geometry_SPLINE(2)=makeSPLINEarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);

        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(2));

        % "close" the boundary with a segment
        geometry_SPLINE(3)=makeSPLINEarc('segment','extrema',[Pend; Pinit]);

        % join piecewise SPLINE
        geometry_SPLINE=joinNURBSPLarcs(geometry_SPLINE);

    case 13 % variable order
        domain_str1='domain 13, defined by a disk, an ellipse, a segment';
        domain_str2=' and a free SPLINE (variable order)';
        domain_str=strcat(domain_str1,domain_str2);

        % add arc of a disk
        geometry_SPLINE(1)=makeSPLINEarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE(1));

        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(end));

        % add arc of an ellipse
        geometry_SPLINE(2)=makeSPLINEarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);

        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(end));

        % add segment
        geometry_SPLINE(3)=makeSPLINEarc('segment','extrema',[Pend; 0 Pend(2)]);

        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE);

        % "close" the boundary with a "free" SPLINE.
        geometry_SPLINE(4)=makeSPLINEarc('free',...
            'P',[0 Pend(2); -1.2 0.3; -1.0 0.5; Pinit],'order',4);

        % join piecewise SPLINE
        geometry_SPLINE=joinNURBSPLarcs(geometry_SPLINE);



    otherwise % variable order
        domain_str1='domain defined by a disk, an ellipse, a segment';
        domain_str2=' and a free SPLINE (variable order)';
        domain_str=strcat(domain_str1,domain_str2);

        % add arc of a disk
        geometry_SPLINE(1)=makeSPLINEarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE(1));

        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(end));

        % add arc of an ellipse
        geometry_SPLINE(2)=makeSPLINEarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);

        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(end));

        % add segment
        geometry_SPLINE(3)=makeSPLINEarc('segment','extrema',[Pend; 0 Pend(2)]);

        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE);

        % "close" the boundary with a "free" SPLINE.
        geometry_SPLINE(4)=makeSPLINEarc('free',...
            'P',[0 Pend(2); -1.9 0.3; -1.8 0.5; Pinit],'order',3);

        % join piecewise SPLINE
        geometry_SPLINE=joinNURBSPLarcs(geometry_SPLINE);
end








function deltaVmaxRE=random_polynomials_tests(n,xyw,xyw0,...
    number_experiments)





for jj=1:number_experiments

    % Random polynomial integrand of degree "n"
    k1=rand(1); k2=rand(1); c1=rand(1);
    f=@(x,y) (c1+k1*x+k2*y).^n;


    % ............. reference value by splinegauss_2021b ............

    fnodes=feval(f,xyw(:,1),xyw(:,2));
    I_2021=xyw(:,3)'*fnodes;

    % ................ reference value by splcub ......................
    fnodes=feval(f,xyw0(:,1),xyw0(:,2));
    I_2019=xyw0(:,3)'*fnodes;

    % ...................... statistics ...............................


    % ... Absolute error ...
    deltaVRE(jj)=abs(I_2019-I_2021(end));


end



% absolute and relative errors

deltaVmaxRE=max(deltaVRE);







%==========================================================================
% chebmom
%==========================================================================

function [Iexact] = exact_integral(a,b,c,n,Sx,Sy)

% OBJECT:
% computes the exact integral up to degree m of a total-degree polynomial
% (a+bx+cy)^n to the Lebesgue measure in a Jordan spline polygon,
% whose boundary is given by the counterclockwise concatened spline
% arcs (Sx,Sy)
%
% INPUT:
% a,b,c,n: constants for polynomial definition
% Sx,Sy: arrays of spline structures; (SX(i),Sy(i)) is the i-th arc
% the arcs must be counterclockwise concatenated forming a Jordan curve
% Sx(i).breaks(end)=Sx(i+1).breaks(1),Sy(i).breaks(end)=Sy(i+1).breaks(1)
% i=1,...,end, with end+1:=1

% OUTPUT:
% Iexact: integral value
%
% DATA:
% built: June 6, 2020
% check: June 6, 2020
% modified: June 6, 2020

xyw=lineint(n,Sx,Sy);
intV=intpoly(a,b,c,n,xyw(:,1:2));
Iexact=intV'*xyw(:,3);





%==========================================================================
% plot_errors
%==========================================================================

function plot_errors(ii,n,reV,log_re)

% set(gca,'YTickLabel',[10.^(-16:1:11)])
set(gca,'TickLength',[0 0]);
xlim([0 25]);
if ii <= 5
    switch ii
        case 1
            plotstr='m+'; linestr='m-';
        case 2
            plotstr='g+'; linestr='g-';
        case 3
            plotstr='r+'; linestr='r-';
        case 4
            plotstr='b+'; linestr='b-';
        case 5
            plotstr='c+'; linestr='b-';
        otherwise
            plotstr='k.'; linestr='w.';
    end
    %     semilogy(1:number_experiments,reV,plotstr); hold on;
    %     semilogy(1:number_experiments,log_reV(ii)*ones(1,number_experiments),...
    %         linestr,'Linewidth',3);
    semilogy(n*ones(size(reV)),reV,plotstr); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',20,'MarkerEdgeColor','k');
else
    semilogy(n*ones(size(reV)),reV,'color',rand(1,3)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',29,'MarkerEdgeColor','k');
end
