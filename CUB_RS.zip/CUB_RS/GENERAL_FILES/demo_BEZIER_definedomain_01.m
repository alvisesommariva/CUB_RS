
function demo_BEZIER_definedomain_01

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo on 
% 1. how to define a BEZIER composite boundary, using elliptical arcs,
%    and "free bezier" composite arc. 
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 14, 2021.
%--------------------------------------------------------------------------

% Define first structure of the curve (an ellipse).
geometry_BEZIER(1)=makeBEZIERarc('elliptical_arc','center',[1 5],...
     'angles',[0 pi],'ell_axis',[2 1]);

% Last point of the previous curve. 
P0=lastpointNURBSPL(geometry_BEZIER(end));

% First point of the previous curve. 
P1=firstpointNURBSPL(geometry_BEZIER(end));

% Define next structure of the curve (an ellipse). 
P=[P0; 0 -0.5; 0 -0.7; P1];
geometry_BEZIER(2)=makeBEZIERarc('free','P',P,'order',4);
        
% Important: Join the structures if they are more then one.
structure_BEZIER=joinNURBSPLarcs(geometry_BEZIER);        

% Plot domain and pointset.
clf;
figure(1)
axis equal
hold on;
% A. plot curve
plotNURBSPL(structure_BEZIER);

hold off;


