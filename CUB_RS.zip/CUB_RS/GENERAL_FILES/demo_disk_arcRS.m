
function demo_disk_arcRS

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This demo plots the arc of the disk, with center equal to "center", with
% polar angles in
%                      [angles(1) angles(2)]
% radius equal to "radius".
%
% Since it may be that "angles(1) > angles(2)" when the arc is ordered
% clockwise, the routine shows that in these instances the codes are fine.
%
% IMPORTANT: in the spline and Bezier composite curve case, we provide only
% an approximation of a disk, while in the NURBS case it is "numerically"
% exact.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% First version: October 31, 2021;
% Checked: November 18, 2021.
%--------------------------------------------------------------------------

% ........................... Settings  ...................................

example=1; % 1: SPLINE, 2: BEZIER, 3: NURBS.

center=[0 0];

angles(1)=0;
angles(2)=pi/4;

radius=1;

geometry0=makeNURBSarc('disk_arc','center',center,'angles',[0 2*pi],...
    'radius',radius);


% ........................... Compute arc  ................................

switch example
    case 1
        fprintf('\n \t APPROXIMATED DISK ARC BY SPLINES');
        geometry=makeSPLINEarc('disk_arc','center',[0 0],'angles',angles,...
            'radius',radius);
        
    case 2
        fprintf('\n \t APPROXIMATED DISK ARC BY BEZIER');
        geometry=makeBEZIERarc('disk_arc','center',[0 0],'angles',angles,...
            'radius',radius);
        
    case 3
        fprintf('\n \t DISK ARC BY NURBS');
        geometry=makeNURBSarc('disk_arc','center',[0 0],'angles',angles,...
            'radius',radius);
        
end


% ........................... Plot arc & moving point .....................

fprintf('\n');
h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis square;
plotNURBSPL(geometry0);
% plotNURBSPL(geometry,'dynamic');
hold off;


% ........................ Test quality approximant .......................

[SxN,SxD,SyN,SyD]=NURBSPL2ratsplines(geometry);

SxN0=SxN(1); t0=SxN0.breaks; t0=t0(1);
SxN1=SxN(end); t1=SxN1.breaks; t1=t1(end);

tt=linspace(t0,t1,1000); tt=tt';
X=fnval(SxN,tt)./fnval(SxD,tt); Y=fnval(SyN,tt)./fnval(SyD,tt);
th=angle(X-center(1)+i*(Y-center(2)));

XY=bsxfun(@plus,center,radius*[cos(th) sin(th)]);

fprintf('\n \t INF NORM ERROR: %1.3e \n',norm(XY-[X Y],inf))



