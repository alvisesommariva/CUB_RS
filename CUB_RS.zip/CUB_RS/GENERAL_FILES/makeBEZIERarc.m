
function geometry_BEZIER=makeBEZIERarc(domain_str,varargin)

%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% This routine, given a certain domain by its geometrical definitions
% provides the relative BEZIER parameters (control points, weights, knots,
% order) storing them in a structured array "structure_arc".
% See demos in the folder for defining geometries.
%
% Important: arc of disks and ellipses are only approximated.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% geometry_BEZIER: Composite Bezier structure.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 18, 2021.
%--------------------------------------------------------------------------

switch domain_str
    case 'disk_arc'
        center=varargin{2}; theta=varargin{4}; r=varargin{6};
        
        % discretization interval theta in Npts segments
        precision='high';
        if strcmp(precision,'low')
            % Max. Error curve vs unit disk: 2.4184e-10
            Npts=10;
        else % Max. Error curve vs unit disk: 3.1086e-15
            Npts=70;
        end
        
        [P,w,knots,order]=compute_arcbez_parms(center,r,...
            theta(1),theta(2),Npts);
        geometry_BEZIER.shape='disk_arc';
        
    case 'elliptical_arc'
        center=varargin{2}; theta=varargin{4}; ell_axis=varargin{6};
        if nargin < 8
            tilt_angle = 0;
        else
            tilt_angle=varargin{8};
        end
        
        % discretization interval theta in Npts segments
        precision='high';
        if strcmp(precision,'low')
            % Max. Error curve vs ellipse with semiaxes [1 2]: 6.069e-10.
            Npts=10; 
        else
            % Max. Error curve vs ellipse with semiaxes [1 2]: 5.429e-14 
            Npts=50;
        end
        
        [P,w,knots,order]=compute_ellarcbez_parms(center,theta,ell_axis,...
            tilt_angle,Npts);
        geometry_BEZIER.shape='elliptical_arc';
        
    case 'polygonal_arc'
        vertices=varargin{2};
        [P,w,knots,order]=compute_polygonbez_parms(vertices);
        geometry_BEZIER.shape='polygonal_arc';
        
    case 'segment'
        vertices=varargin{2};
        [P,w,knots,order]=compute_segmentsbez_parms(vertices);
        geometry_BEZIER.shape='segment';
        
    case 'free'
        P=varargin{2}; order=varargin{4};
        if nargin >= 6
            knots=varargin{6};
        else
            L=size(P,1); knots=linspace(0,L-1,L);
        end
        geometry_BEZIER.shape='free';
end

geometry_BEZIER.type='bezier';
geometry_BEZIER.P=P;
geometry_BEZIER.w=[];
geometry_BEZIER.knots=knots;
geometry_BEZIER.order=order;







function [P,w,knots,order]=compute_arcbez_parms(center,r,theta0,theta1,...
    Npts)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This routine defines an arc of circle (via composite Bezier param curve).
% Arc equation (without tilting):
% * x(t)=center(1)+r*cos(t)
% * y(t)=center(2)+r*sin(t)
% with "theta" in "[theta0,theta1]".
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% center: center of the circle containing the arc.
% r: radius of the circle containing the arc.
% theta0,theta1: angles of the extrema of the arc; notice that the arc goes
%   from "theta0" to "theta1" counterclockwise.
% Npts: number of equispaced points to approximatively needed to
%    approximate arc.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% P: control points.
% w: BEZIER weights.
% knots: BEZIER weights.
% order: BEZIER order.
%--------------------------------------------------------------------------
% REFERENCE:
%--------------------------------------------------------------------------
% https://stackoverflow.com/questions/1734745/how-to-create-circle-with-
% b�zier-curves
%--------------------------------------------------------------------------
% DATE:
%--------------------------------------------------------------------------
% Written: November 13, 2021.
% Checked: November 18, 2021.
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% Troubleshooting.
%--------------------------------------------------------------------------

if nargin < 1, center=[0 0]; end
if nargin < 2, r=1; end
if nargin < 3, theta0=0; end
if nargin < 4, theta1=2*pi; end
if nargin < 5, Npts=150; end

if isempty(center), center=[0 0]; end
if isempty(r), r=1; end
if isempty(theta0), theta0=0; end
if isempty(theta1), theta1=1; end
if isempty(Npts), Npts=150; end

%--------------------------------------------------------------------------
% Control Points
%--------------------------------------------------------------------------

if theta0 > theta1
    flag=0; [theta1,theta0]=deal(theta0,theta1);
else
    flag=1;
end

% general case in which "0 < theta1-theta0 <= 2*pi", with "theta0" and
% "theta1" not necessarily in [0,2*pi]
ampl=(theta1-theta0);
pieces=ceil(ampl*Npts/(pi/2));
theta=ampl/pieces; % subdividing in pieces of amplitude at most pi/2.

% reference: https://www.joecridge.me/bezier.pdf
alpha=theta/2;
lambda=(4-cos(alpha))/3;
mu=sin(alpha)+(4/3)*(cos(alpha)-1)*cot(alpha);
Pref(1,:)=[cos(alpha) -sin(alpha)];
Pref(2,:)=[lambda -mu];
Pref(3,:)=[lambda +mu];
Pref(4,:)=[cos(alpha) sin(alpha)];

% Reference piece "Pref" in [0,theta].
R=[cos(alpha) -sin(alpha); sin(alpha) cos(alpha)];
Pref=Pref*R';

% Computing all control points (no repetitions) in [0,ampl].
PL=Pref; P=Pref;
R=[cos(theta) -sin(theta); sin(theta) cos(theta)];
for k=2:pieces
    PL=PL*R';
    P=[P; PL(2:end,:)];
end

% rotate to initial point "theta0"
R=[cos(theta0) -sin(theta0); sin(theta0) cos(theta0)];
P=bsxfun(@plus,center,r*P*R');

w=[];

order=4;

L=size(P,1);
knots=linspace(0,1,L);


if flag == 0
    P=flipud(P);
end







function  [P,w,knots,order]=compute_ellarcbez_parms(center,theta,...
    ell_axis,tilt_angle,Npts)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This routine defines an arc of ellipse (possibly tilted).
% Ellipse equation (without tilting):
% * x(t)=center(1)+a*cos(t)
% * y(t)=center(2)+b*sin(t)
%
% IMPORTANT:
% For the spline case, the ellipse is ONLY an approximation of the needed
% one.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% center: center of the ellipse
% angles: angles of the extrema of the elliptical arc.
% ell_axis: it is a 2 x 1 vector, where the first component describes the
%         half width "a" while the second component described the half
%         height "b".
% tilt_angle: angle of rotation of the ellipse with respect to the x-axis;
%         this variable is not mandatory (default value: 0).
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% P: control points.
% w: SPLINE weights.
% knots: SPLINE weights.
% order: SPLINE order.
%--------------------------------------------------------------------------
% DATE:
%--------------------------------------------------------------------------
% Written: November 4, 2021.
% Checked: November 18, 2021.
%--------------------------------------------------------------------------


%--------------------------------------------------------------------------
% Troubleshooting
%--------------------------------------------------------------------------

if nargin < 1, center=[0 0]; end
if nargin < 2, theta=[0 2*pi]; end
if nargin < 3, ell_axis=[1 1]; end
if nargin < 4, tilt_angle=0; end
if nargin < 5, Npts=150; end

if isempty(center), center=[0 0]; end
if isempty(theta), theta=[0 2*pi]; end
if isempty(ell_axis), ell_axis=[1 1]; end
if isempty(tilt_angle), tilt_angle=0; end
if isempty(Npts), Npts=150; end

theta0=theta(1); theta1=theta(2);

if theta0 > theta1
    flag=0; [theta1,theta0]=deal(theta0,theta1);
else
    flag=1;
end

theta0=theta(1); theta1=theta(2);

a=ell_axis(1); b=ell_axis(2);

%--------------------------------------------------------------------------
% Control Points
%--------------------------------------------------------------------------

center0=[0 0]; r0=1;

[P,w,knots,order]=compute_arcbez_parms(center0,r0,theta0,theta1,...
    Npts);

X=P(:,1); Y=P(:,2);
P=[a*X b*Y];

if not(tilt_angle == 0)
    R=[cos(tilt_angle) -sin(tilt_angle); sin(tilt_angle) cos(tilt_angle)];
    P=P*R';
end

P=bsxfun(@plus,center,P);
w=[];
order=4;
L=size(P,1); knots=linspace(0,1,L); % equispaced parametrization.







function [P,w,knots,order]=compute_polygonbez_parms(vertices)

P=vertices; % matrix N x 2
w=[];
L=size(P,1);
knots=linspace(0,1,L);
order=2;







function [P,w,knots,order]=compute_segmentsbez_parms(vertices)

P=vertices;
w=[];
knots=[0 1];
order=2;

