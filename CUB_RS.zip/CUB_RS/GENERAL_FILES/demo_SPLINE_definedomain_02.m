
function demo_SPLINE_definedomain_02(domain_type)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating:
% 1. how to define a SPLINE on a composite boundary, using arcs of disks,
%    ellipses, segments, polygons and "free SPLINE". The routines work on
%    piecewise SPLINE of different order.
%    To this purpose see the MATLAB function "define_domain" at the
%    bottom of this demo (about at line 68).
%--------------------------------------------------------------------------

% The variable "domain_type" set the domain taken into account. The
% invented names are just given to remember something of the region.
%
%       0. Disk
%       1. Lune like
%       2. Tau-like-symbol
%       3. Quadrangloid
%       4. Curved trapezoid
%       5. Weird eta
%       6. Weird eta 2
%       7. Weird eta 3
%       8. Weird eta skinny
%       9. Rough ball
%      10. L-shaped
%      11. M-shaped domain
%      12. defined by a disk, an ellipse and a segment
%      13. defined by a disk, an ellipse, a segment and a free SPLINE
%          (variable order)
%      otherwise: defined by a disk, an ellipse, a segment and a free SPLINE
%          (variable order)

if nargin < 1, domain_type=10; end



% ----------------------------- Main code ---------------------------------

%--------------------------------------------------------------------------
% 1. Make SPLINE structure
%--------------------------------------------------------------------------

[structure_SPLINE,domain_str]=define_domain(domain_type);

%--------------------------------------------------------------------------
% 2. Plot domain and control points polygon.
%--------------------------------------------------------------------------

h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis equal;

% A. plot SPLINE curve (black)
plotNURBSPL(structure_SPLINE)
hold off;






%--------------------------------------------------------------------------
% ATTACHED ROUTINES
%--------------------------------------------------------------------------

function [geometry_SPLINE,domain_str]=define_domain(example)

switch example
    
    case 0 % circle
        domain_str='circle';
         geometry_SPLINE=makeSPLINEarc('disk_arc','center',[0 0],...
            'angles',[0 2*pi],'radius',1);
        
        
    case 1 % lune-like
        domain_str='lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        order=3;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
        
    case 2 
        domain_str='Tau-like-symbol';
        P=[1 0; 0.8 0.1; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5;  ...
            0.2 -0.45; -0.4 -0.4; 0 -1; 1 -1;  1 0];
        order=3;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
        
    case 3 
        domain_str='Quadrangloid';
        P=[1 0; 1 1; 0 1; -1 1; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        order=4;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
        
        
    case 4 
        domain_str='Curved trapezoid';
        P=[1 0; 1 1; 0 1; -1 0.6; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        order=4;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
        
    case 5
        domain_str='Weird eta';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.1 0.1; 0 0.5; 1 -1;  1 0];
        order=4;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
    case 6 
        domain_str='Weird eta 2';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 -1; 0 0.5; 1 -1;  1 0];
        order=4;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
        
    case 7 
        domain_str='Weird eta 3';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.4 0.6; 0 -0.5; 1 -1;  1 0];
        order=4;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
    case 8 
        domain_str='Weird eta skinny';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 0.5; 1 -1;  1 0];
        order=4;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
    case 9 % rough-ball
        domain_str='rough ball';
        sidesL=20;
        t=linspace(0,2*pi,sidesL); t=t';
        P=[cos(t) sin(t)]; P=[P(1:end-1,:); P(1,:)];
        order=3;
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
    case 10 % L-shaped domain
        
        domain_str='L shaped domain';
        P=[-1 1; -1 -1; 1 -1; 1 -0.6; -0.6 -0.6; -0.6 1; -1 1]; % 7 points
        order=3;
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
    case 11 % M-shaped domain
        
        domain_str='M shaped domain';
        order=3;
        P=[-1 1; -1 0; -1 -1; -0.6 -1; -0.6 0; -0.6 0.6; 0 0; 0.6 0.6; ...
            0.6 0; 0.6 -1; 1 -1; 1 0; 1 1; 0.6 1; 0 0.4; -0.6 1; -1 1];
        
        geometry_SPLINE=makeSPLINEarc('free','P',P,'order',order);
        
    case 12 % variable order
        domain_str='domain 12, defined by a disk, an ellipse and a segment';
        
        
        % add arc of a disk
        geometry_SPLINE(1)=makeSPLINEarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);
        
        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE(1));
        
        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(1));
        
        % add arc of an ellipse
        geometry_SPLINE(2)=makeSPLINEarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);
        
        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(2));
        
        % "close" the boundary with a segment
        geometry_SPLINE(3)=makeSPLINEarc('segment','extrema',[Pend; Pinit]);
        
        % join piecewise SPLINE
        geometry_SPLINE=joinNURBSPLarcs(geometry_SPLINE);
        
    case 13 % variable order
        domain_str1='domain 13, defined by a disk, an ellipse, a segment';
        domain_str2=' and a free SPLINE (variable order)';
        domain_str=strcat(domain_str1,domain_str2);
        
        % add arc of a disk
        geometry_SPLINE(1)=makeSPLINEarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);
        
        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE(1));
        
        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(end));
        
        % add arc of an ellipse
        geometry_SPLINE(2)=makeSPLINEarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);
        
        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(end));
        
        % add segment
        geometry_SPLINE(3)=makeSPLINEarc('segment','extrema',[Pend; 0 Pend(2)]);
        
        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE);
        
        % "close" the boundary with a "free" SPLINE.
        geometry_SPLINE(4)=makeSPLINEarc('free',...
            'P',[0 Pend(2); -1.2 0.3; -1.0 0.5; Pinit],'order',4);
        
        % join piecewise SPLINE
        geometry_SPLINE=joinNURBSPLarcs(geometry_SPLINE);
        
        
        
    otherwise % variable order
        domain_str1='domain defined by a disk, an ellipse, a segment';
        domain_str2=' and a free SPLINE (variable order)';
        domain_str=strcat(domain_str1,domain_str2);
        
        % add arc of a disk
        geometry_SPLINE(1)=makeSPLINEarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);
        
        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE(1));
        
        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(end));
        
        % add arc of an ellipse
        geometry_SPLINE(2)=makeSPLINEarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);
        
        % compute last point of the so made SPLINE
        Pend=lastpointNURBSPL(geometry_SPLINE(end));
        
        % add segment
        geometry_SPLINE(3)=makeSPLINEarc('segment','extrema',[Pend; 0 Pend(2)]);
        
        % compute first point of the piecewise SPLINE domain
        Pinit=firstpointNURBSPL(geometry_SPLINE);
        
        % "close" the boundary with a "free" SPLINE.
        geometry_SPLINE(4)=makeSPLINEarc('free',...
            'P',[0 Pend(2); -1.9 0.3; -1.8 0.5; Pinit],'order',3);
        
        % join piecewise SPLINE
        geometry_SPLINE=joinNURBSPLarcs(geometry_SPLINE);
end


