
function demo_SPLINE_hyp_00

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Demo on how to define hyperinterpolation on a SPLINE composite boundary, 
% based on arcs of disks and polygonal arcs. 
%
% The fact that hyperinterpolant of degree "deg" is numerically exact,
% shows that cubature formula are exact.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 18, 2021;
% Checked: November 18, 2021.
%--------------------------------------------------------------------------

% ......................... Problem Settings  ............................. 

deg=5; % hyperinterpolation degree
f=@(x,y) (2*x+3*y+0.3).^deg; % function to hyperinterpolate
Ngrid=100;


% ....................... Define domain structure ......................... 

geometry_RS(1)=makeSPLINEarc('disk_arc','center',[0 0],...
     'angles',[0 pi],'radius',1);
geometry_RS(2)=makeSPLINEarc('polygonal_arc','vertices',...
    [-1 0; 0 -1; 1 0]);
structure_RS=joinNURBSPLarcs(geometry_RS);


% ....................... Perform hyperinterpolation ......................

[coeff,R,jvec,dbox] = hypRSfit(deg,structure_RS,f);

% ............... Evaluate hyperinterpolant in points in domain ...........
pts=ptsRS(structure_RS,Ngrid); 
in=inRS(pts,structure_RS); iok=find(in == 1); pts0=pts(iok,:);
pval = hypRSval(deg,coeff,pts0,R,jvec,dbox);

% ............................ Test error .................................

fpts=feval(f,pts0(:,1),pts0(:,2));
AE=norm(pval-fpts,inf);

% ............................ Plot figure ................................

h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis equal;

% A. plot domain boundary
plotNURBSPL(structure_RS);

% B. plot test points.

plot(pts0(:,1),pts0(:,2),'g*','MarkerEdgeColor','g',...
    'MarkerFaceColor','g','MarkerSize',2);

hold off;

% ......................... Display statistics ............................
fprintf('\n \t Algebraic Degree of Exactness: %2.0g',deg);
fprintf('\n \t Absolute hyperinterp. error  : %1.3e \n',AE);

