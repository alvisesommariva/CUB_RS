
function demo_SPLINE_definedomain_00

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating:
% 1. how to define a SPLINE on a composite boundary, using arcs of disks,
%    ellipses, segments, polygons and "free SPLINE". The routines work on
%    piecewise SPLINE of different order.
%    The result is a vector "geometry_SPLINE" of a structure that takes 
%    into account control points, knots, weights and orders.
% 2. the application of the "joinSPLINEarcs" is important in case the 
%    length of the vector "geometry_SPLINE" is larger than one, in order to
%    make a"consistent" piecewise SPLINE in which knots are well-ordered. 
% 3. plot the parametric spline curve dirctly from the geometry by 
%    "plotNURBSPL".
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------

% ......................... Design SPLINE pieces  .......................... 

% add arc of a disk
fprintf('\n \t * Defining arc of a disk');
geometry_SPLINE(1)=makeSPLINEarc('disk_arc','center',[0 0],...
    'angles',[0 pi/2],'radius',1);

% compute last point of the so made SPLINE
fprintf('\n \t * Computing last point of a SPLINE');
Pend=lastpointNURBSPL(geometry_SPLINE);

% add arc of an ellipse
fprintf('\n \t * Defining arc of an ellipse');
geometry_SPLINE(2)=makeSPLINEarc('elliptical_arc',... 
    'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
    'tilt_angle',0);

% compute last point of the so made SPLINE
fprintf('\n \t * Computing last point of a SPLINE');
Pend=lastpointNURBSPL(geometry_SPLINE);

% add segment
fprintf('\n \t * Defining a polygonal_arc');
geometry_SPLINE(3)=makeSPLINEarc('polygonal_arc',...
    'extrema',[Pend; 0 Pend(2)]);

% compute first point of the piecewise SPLINE domain
fprintf('\n \t * Computing first point of a SPLINE');
Pinit=firstpointNURBSPL(geometry_SPLINE);

P=[0 Pend(2); -1.5 0.3; -1.3 0.5; Pinit];
knots=linspace(0,1,size(P,1));
geometry_SPLINE(4)=makeSPLINEarc('free','P',P,'order',3);

% ......................... Join SPLINE pieces  ............................ 

% make unique SPLINE structure (very important step!)
fprintf('\n \t * Joining piecewise SPLINE into one well def. structure');
geometry_SPLINE=joinNURBSPLarcs(geometry_SPLINE);

% ......................... Plot SPLINE pieces  ............................

% plot piecewise SPLINE curve
fprintf('\n \t * Plotting piecewise SPLINE');
plotNURBSPL(geometry_SPLINE);

fprintf('\n');


