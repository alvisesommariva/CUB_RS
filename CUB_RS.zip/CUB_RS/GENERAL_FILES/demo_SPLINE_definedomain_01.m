
function demo_SPLINE_definedomain_01

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating:
% 1. how to define a SPLINE on a composite boundary, using arcs of disks,
%    ellipses, segments, polygons and "free SPLINE". The routines work on
%    piecewise SPLINE of different order.
%    The result is a vector "geometry_SPLINE" of a structure that takes into
%    account control points, knots, weights and orders.
% 2. the application of the "joinSPLINEarcs" is important in case the length
%    of the vector "geometry_SPLINE" is larger than one, in order to make a
%    "consistent" piecewise SPLINE in which knots are well-ordered. 
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------

% ......................... Design SPLINE pieces  .......................... 

% add arc of a disk
fprintf('\n \t * Defining arc of a disk');
geometry_SPLINE(1)=makeSPLINEarc('disk_arc','center',[0 0],...
    'angles',[0 2*pi],'radius',1);

% It is not necessary to order the spline knots (just one spline!)

% ......................... Plot SPLINE pieces  ............................

% plot piecewise SPLINE curve
fprintf('\n \t * Plotting piecewise SPLINE');
axis square; 
plotNURBSPL(geometry_SPLINE);

fprintf('\n');


