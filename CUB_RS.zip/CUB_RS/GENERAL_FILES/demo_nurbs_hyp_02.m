
function demo_NURBS_hyp_02(domain_type)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Demo on how to define hyperinterpolation on a NURBS composite boundary,
% based on arcs of disks and polygonal arcs.
%
% The fact that hyperinterpolant of degree "deg" is numerically exact,
% shows that cubature formula are exact.
%--------------------------------------------------------------------------
% Note
%--------------------------------------------------------------------------
% We provide experiments testing hyperinterpolant reconstruction at degree
% "n" of a polynomial of degree "n". The error seems to increase with the
% degree. Below the example on the L-domain (domain_type=10).
% 
% >> demo_nurbs_hyp_02
% 
%  	 Alg. Degree of Exactness    :  2
%  	 Non filtered inf.norm error : 2.442e-15
%  	 Filtered inf.norm error     : 2.442e-15
%  	 Median inf.norm error       : 4.857e-16 
%  
% >> demo_nurbs_hyp_02
% 
%  	 Alg. Degree of Exactness    :  4
%  	 Non filtered inf.norm error : 1.776e-14
%  	 Filtered inf.norm error     : 1.776e-14
%  	 Median inf.norm error       : 4.635e-15 
%  
% >> demo_nurbs_hyp_02
% 
%  	 Alg. Degree of Exactness    :  6
%  	 Non filtered inf.norm error : 2.727e-13
%  	 Filtered inf.norm error     : 2.727e-13
%  	 Median inf.norm error       : 3.062e-14 
%  
% >> demo_nurbs_hyp_02
% 
%  	 Alg. Degree of Exactness    :  8
%  	 Non filtered inf.norm error : 4.504e-12
%  	 Filtered inf.norm error     : 4.504e-12
%  	 Median inf.norm error       : 7.112e-13 
% 
% >> demo_nurbs_hyp_02
% 
%  	 Compression not completed. Moment error: 1.825e-01
%  	 Tried backslash (PO rule): OK. Mom. error: 6.949e-14 
%  	 NEGATIVE WEIGHTS:       69 
%  	 Alg. Degree of Exactness    : 10
%  	 Non filtered inf.norm error : 6.203e-11
%  	 Filtered inf.norm error     : 5.878e-11
%  	 Median inf.norm error       : 1.216e-11 
%
% Notice the presence of negative weights, since the method fails in 
% providing a rule (numerical issues at mild degrees) but the 
% reconstruction still works rather fine.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 18, 2021;
% Checked: November 18, 2021.
%--------------------------------------------------------------------------


% ......................... Problem Settings  .............................

deg=10; % hyperinterpolation degree

% The variable "domain_type" set the domain taken into account. The
% invented names are just given to remember something of the region.
%
%       0. Disk
%       1. Lune like
%       2. Tau-like-symbol
%       3. Quadrangloid
%       4. Curved trapezoid
%       5. Weird eta
%       6. Weird eta 2
%       7. Weird eta 3
%       8. Weird eta skinny
%       9. Rough ball
%      10. L-shaped
%      11. M-shaped domain
%      12. defined by a disk, an ellipse and a segment
%      13. defined by a disk, an ellipse, a segment and a free "spline"
%          (variable order)
%      otherwise: defined by a disk, an ellipse, a segment and a free RS
%          domain (variable order)
if nargin < 1, domain_type=10; end

f=@(x,y) (1.2*x+1.5*y+1).^deg; % function to hyperinterpolate
Ngrid=100;


% ....................... Define domain structure .........................

[structure_RS,domain_str]=define_domain(domain_type);

% ....................... Perform hyperinterpolation ......................

[coeff,R,jvec,dbox] = hypRSfit(deg,structure_RS,f);

% ............... Evaluate hyperinterpolant in points in domain ...........
pts=ptsRS(structure_RS,Ngrid);
in=inRS(pts,structure_RS); iok=find(in == 1); pts0=pts(iok,:);
pval = hypRSval(deg,coeff,pts0,R,jvec,dbox);

% ............................ Test error .................................


fpts=feval(f,pts0(:,1),pts0(:,2));

% we do not consider points with too large or too small values. Of the
% remaining ones we test the quality of the approximation.

AEs=abs(pval-fpts);
AE0=norm(pval-fpts,inf);
tol=10^(-12);
iok=find(fpts >= tol & fpts <=1/tol);
if length(iok) > 0
    pval0=pval(iok); fpts0=fpts(iok);
    AE=norm(pval0-fpts0,inf);
    RE=norm((pval0-fpts0)./fpts0,inf);
else
    AE=NaN;
end

% ............................ Plot figure ................................

h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis equal;

% A. plot domain boundary
plotNURBSPL(structure_RS);

% B. plot test points.

plot(pts0(:,1),pts0(:,2),'g*','MarkerEdgeColor','g',...
    'MarkerFaceColor','g','MarkerSize',2);

hold off;

% ......................... Display statistics ............................
fprintf('\n \t Alg. Degree of Exactness    : %2.0f',deg);
fprintf('\n \t Non filtered inf.norm error : %1.3e',AE0);
fprintf('\n \t Filtered inf.norm error     : %1.3e',AE);
fprintf('\n \t Median inf.norm error       : %1.3e \n \n',median(AEs));









%--------------------------------------------------------------------------
% ATTACHED ROUTINES
%--------------------------------------------------------------------------

function [geometry_NURBS,domain_str]=define_domain(example)

switch example

    case 0 % circle
        domain_str='circle';
        P=[1 0; 1 1; 0 1; -1 1; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        knots=[0 0 0 .25 .25 .5 .5 .75 .75 1 1 1];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];
        order=3;
        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 1 % lune-like
        domain_str='lune-like';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5; 0 -1; ...
            1 -1;  1 0];
        knots=[0 0 0 .15 .25 .25 .5 .5 .75 .75 1 1 1];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1];
        order=3;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 2 % tau-like-symbol
        domain_str='tau-like-symbol';
        P=[1 0; 0.45 0.37; 1 1; 0 1; -0.8 0.9; -1 0; 0.3 0.5;  ...
            0.2 -0.45; -0.4 -0.4; 0 -1; 1 -1;  1 0];
        knots=[0 0 0 .15 .25 .25 .5 .5 .6 .7 .75 .75 1 1 1];
        c=1/sqrt(2); w=[1 c c 1 c 1 c 1 c 1 c 1];
        order=3;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 3 % cubic-domain
        domain_str='cubic-domain: leaf';
        P=[1 0; 1 1; 0 1; -1 1; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        knots=[0 0 0 0 .25 .25 .25 .5 .75 1 1 1 1];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];
        order=4;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);



    case 4 % cubic-domain: nut
        domain_str='cubic-domain: slanted nut';
        P=[1 0; 1 1; 0 1; -1 0.6; -1 0; -1 -1; 0 -1; 1 -1;  1 0];
        knots=[0 0 0 0 .25 .25 .25 .25 .5 1 1 1 1];
        c=1/sqrt(2); w=[1 c 1 c 1 c 1 c 1];
        order=4;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 5 % cubic-domain: slanted boomerang
        domain_str='cubic-domain: golf club';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.4 0.6; 0 0.5; 1 -1;  1 0];
        knots=[0 0 0 0 .25 .25 .25 .35 .65 1 1 1 1];
        c=1/sqrt(2); w=[1 c/2 1 c/4 1 c/4 1 c 1];
        order=4;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 6 % cubic-domain: nut
        domain_str='cubic-domain: dino head';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 -1; 0 0.5; 1 -1;  1 0];
        knots=[0 0 0 0 .25 .25 .25 .35 .65 0.75 1 1 1 1];
        c=1/sqrt(2); w=[1 c/2 1 c/4 1 c/4 1 1 c 1];
        order=4;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);


    case 7 % cubic-domain: slanted boomerang
        domain_str='cubic-domain: tadpole';
        P=[1 0; 1 1; 0 1;  -1 0;  -1 -1; -0.4 0.6; 0 -0.5; 1 -1;  1 0];
        knots=[0 0 0 0 .25 .3 .35 .45 .65 1 1 1 1];
        c=1/sqrt(2); w=[1 1 1 1 1 1 1 1 1];
        order=4;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 8 % cubic-domain: nut
        domain_str='cubic-domain: nose';
        P=[1 0; 1 1; 0 1; -0.4 0.6; -1 0; -1 -1; 0 0.5; 1 -1;  1 0];
        knots=[0 0 0 0 .25 .25 .25 .35 .65 1 1 1 1];
        c=1/sqrt(2); w=[1 5 5 5 5 5 5 5 1];
        order=4;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 9 % rough-ball
        domain_str='rough ball';
        order=3;
        sidesL=20;
        t=linspace(0,2*pi,sidesL); t=t';
        P=[cos(t) sin(t)]; P=[P(1:end-1,:); P(1,:)];
        knots_mid=linspace(0.1,0.9,sidesL-order);
        knots=[zeros(1,order) knots_mid ones(1,order)];
        M=size(P,1);
        % w=rand(1,M);
        w=[ 8.258169774895474e-01
            5.383424352600571e-01
            9.961347166268855e-01
            7.817552875318368e-02
            4.426782697754463e-01
            1.066527701805844e-01
            9.618980808550537e-01
            4.634224134067444e-03
            7.749104647115024e-01
            8.173032206534330e-01
            8.686947053635097e-01
            8.443584551091032e-02
            3.997826490988965e-01
            2.598704028506542e-01
            8.000684802243075e-01
            4.314138274635446e-01
            9.106475944295229e-01
            1.818470283028525e-01
            2.638029165219901e-01
            1.455389803847170e-01]';

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 10 % L-shaped domain

        domain_str='L shaped domain';
        P=[-1 1; -1 -1; 1 -1; 1 -0.6; -0.6 -0.6; -0.6 1; -1 1]; % 7 points
        knots=[0 0 0 .15 .25 .35 .65 1 1 1];
        w=[0.2 5 10 10 100 5 0.2];
        order=3;

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 11 % M-shaped domain

        domain_str='M shaped domain';
        order=3;
        P=[-1 1; -1 0; -1 -1; -0.6 -1; -0.6 0; -0.6 0.6; 0 0; 0.6 0.6; ...
            0.6 0; 0.6 -1; 1 -1; 1 0; 1 1; 0.6 1; 0 0.4; -0.6 1; -1 1];
        kk=size(P,1)-order;
        knots_mid=linspace(0.1,0.9,kk);
        knots=[0 0 0 knots_mid 1 1 1]; % 12-3
        w=1000*ones(1,size(P,1));

        geometry_NURBS=makeNURBSarc('free','P',...
            P,'knots',knots,'weights',w,'order',order);

    case 12 % variable order
        domain_str='domain 12, defined by a disk, an ellipse and a segment';

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);
        
        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));
        
        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(1));
        
        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],...
            'ell_axis',[1 2],'tilt_angle',0);
        
        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(2));
        
        % "close" the boundary with a segment
        geometry_NURBS(3)=makeNURBSarc('segment','extrema',...
            [Pend; Pinit]);
        
        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);



    case 13 % variable order

        domain_str1='domain 13, defined by a disk, an ellipse, a segment';
        domain_str2=' and a free NURBS (variable order)';
        domain_str=strcat(domain_str1,domain_str2);

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(end));

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(end));

        % add segment
        geometry_NURBS(3)=makeNURBSarc('segment','extrema',[Pend; 0 Pend(2)]);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS);

        % "close" the boundary with a "free" NURBS.
        geometry_NURBS(4)=makeNURBSarc('free',...
            'P',[0 Pend(2); -1.9 0.3; -1.8 0.5; Pinit],...
            'knots',[0 0 0 0 1 1 1 1],'weights',[1 1 2 1],'order',4);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);



    otherwise % variable order
        domain_str1='domain defined by a disk, an ellipse, a segment';
        domain_str2=' and a free NURBS (variable order)';
        domain_str=strcat(domain_str1,domain_str2);

        % add arc of a disk
        geometry_NURBS(1)=makeNURBSarc('disk_arc',...
            'center',[0 0],'angles',[0 pi/2],'radius',1);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS(1));

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(end));

        % add arc of an ellipse
        geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
            'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
            'tilt_angle',0);

        % compute last point of the so made NURBS
        Pend=lastpointNURBSPL(geometry_NURBS(end));

        % add segment
        geometry_NURBS(3)=makeNURBSarc('segment','extrema',[Pend; 0 Pend(2)]);

        % compute first point of the piecewise NURBS domain
        Pinit=firstpointNURBSPL(geometry_NURBS);

        % "close" the boundary with a "free" NURBS.
        geometry_NURBS(4)=makeNURBSarc('free',...
            'P',[0 Pend(2); -1.9 0.3; -1.8 0.5; Pinit],...
            'knots',[0 0 0 0.5 1 1 1],'weights',[1 1 2 1],'order',3);

        % join piecewise NURBS
        geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);
end