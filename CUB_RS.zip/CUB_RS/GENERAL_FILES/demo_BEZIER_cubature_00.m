
function demo_BEZIER_cubature_00

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating the CUBATURE procedure:
% 1. How to define a composite BEZIER boundary, by means of "makeBEZIERarc"
%   for determining a circular arc of a disk and a "polygonal arc".
% 2. How to call the cubature routine "cubRS".
% 3. How to plot the domain and cubature points.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% First version: October 31, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------


% ------------------------------ Settings ---------------------------------

% Algebraic degree of precision of the cubature rule. Suggested values are
% mild, e.g. not larger than "ade=15". Typical "ade" in the applications
% are between "3" and "5".
ade=5;


% ----------------------------- Main code ---------------------------------

%--------------------------------------------------------------------------
% 1. Make BEZIER structure
%--------------------------------------------------------------------------

% Define structure of an "Ice cream cone with one scoop".
geometry_BEZIER(1)=makeBEZIERarc('disk_arc','center',[0 0],...
     'angles',[0 pi],'radius',1);
geometry_BEZIER(2)=makeBEZIERarc('polygonal_arc','vertices',...
    [-1 0; 0 -1; 1 0]);

% Important: Join the geometries if they are more than one.
structure_BEZIER=joinNURBSPLarcs(geometry_BEZIER);



%--------------------------------------------------------------------------
% 2. Cubature.
%--------------------------------------------------------------------------
xyw = cubRS(ade,structure_BEZIER);



%--------------------------------------------------------------------------
% 3. Plot domain and control points polygon.
%--------------------------------------------------------------------------

h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis equal;

% A. plot SPLINE curve (black)
plotNURBSPL(geometry_BEZIER);

% B. plot nodes.
plot(xyw(:,1),xyw(:,2),'mo','MarkerEdgeColor','k',...
    'MarkerFaceColor','m','MarkerSize',10);

hold off;


%--------------------------------------------------------------------------
% 4. Statistics
%--------------------------------------------------------------------------
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t            BEZIER CUBATURE TESTS \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n');
fprintf('\n \t ALGEBRAIC DEGREE OF PRECISION: %3.0f',ade);
w=xyw(:,3); condcub=sum(abs(w))/sum(w);
fprintf('\n \t CUBATURE CONDITIONING        : %1.5e',condcub);
NN=length(find(xyw(:,3) == 0));
fprintf('\n \t NEGATIVE WEIGHTS             : %6.0f',NN);
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             PLOT DESCRIPTION \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t * Green dots: trial points in domain.   \n \t');
fprintf('\n \t * Red dots: trial points not in domain.   \n \t');
fprintf('\n \t * Magenta dots: quadrature nodes.   \n \t');
fprintf('\n \t ------------------------------------------- \n');









