
function demo_nurbs_definedomain_00

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating:
% 1. how to define a NURBS on a composite boundary, using arcs of disks,
%    ellipses, segments, polygons and "free NURBS". The routines work on
%    piecewise NURBS of different order.
%    The result is a vector "geometry_NURBS" of a structure that takes into
%    account control points, knots, weights and orders.
% 2. the application of the "joinNURBSarcs" is important in case the length
%    of the vector "geometry_NURBS" is larger than one, in order to make a
%    "consistent" piecewise NURBS in which knots are well-ordered. 
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------

% ......................... Design NURBS pieces  .......................... 

% add arc of a disk
fprintf('\n \t * Defining arc of a disk');
geometry_NURBS(1)=makeNURBSarc('disk_arc',...
    'center',[0 0],'angles',[0 pi/2],'radius',1);

% compute last point of the so made NURBS
fprintf('\n \t * Computing last point of a NURBS');
Pend=lastpointNURBSPL(geometry_NURBS);

% add arc of an ellipse
fprintf('\n \t * Defining arc of an ellipse');
geometry_NURBS(2)=makeNURBSarc('elliptical_arc',... 
    'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
    'tilt_angle',0);

% compute last point of the so made NURBS
fprintf('\n \t * Computing last point of a NURBS');
Pend=lastpointNURBSPL(geometry_NURBS);

% add segment
fprintf('\n \t * Defining a polygonal_arc');
geometry_NURBS(3)=makeNURBSarc('polygonal_arc',...
    'extrema',[Pend; 0 Pend(2)]);

% compute first point of the piecewise NURBS domain
fprintf('\n \t * Computing first point of a NURBS');
Pinit=firstpointNURBSPL(geometry_NURBS);

% "close" the boundary with a "free" NURBS.
fprintf('\n \t * Defining arc of a free NURBS');
geometry_NURBS(4)=makeNURBSarc('free','P',...
    [0 Pend(2); -1.9 0.3; -1.8 0.5; Pinit],...
    'knots',[0 0 0 0.5 1 1 1],'weights',[1 1 2 1],'order',3);


% ......................... Join NURBS pieces  ............................ 

% make unique NURBS structure (very important step!)
fprintf('\n \t * Joining piecewise NURBS into one well define structure');
geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);



% ......................... Plot NURBS pieces  ............................

% plot piecewise NURBS curve
fprintf('\n \t * Plotting piecewise NURBS');
plotNURBSPL(geometry_NURBS,'normal');

fprintf('\n');


