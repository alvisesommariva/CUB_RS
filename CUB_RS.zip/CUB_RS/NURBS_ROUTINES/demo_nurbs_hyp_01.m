
function demo_nurbs_hyp_01

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Demo on how to define hyperinterpolation on a NURBS composite boundary, 
% based on arcs of disks and polygonal arcs. 
%
% The fact that hyperinterpolant of degree "deg" is numerically exact,
% shows that cubature formula are exact.
%
% Numerical experiments show deterioration increasing the degree, i.e. the
% error between an hyperinterpolant of degree "deg" and a polynomial of
% degree "deg", grows with "deg".
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 18, 2021;
% Checked: November 18, 2021.
%--------------------------------------------------------------------------

warning off;

% ......................... Problem Settings  ............................. 

deg=16; % hyperinterpolation degree (do not set it larger than 16);
% f=@(x,y) (1.2*x+1.5*y+1).^deg; % function to hyperinterpolate;
f=@(x,y) sin(x+y);
% f=@(x,y) exp(-x.^2-y.^2);
Ngrid=100;


% ....................... Define domain structure ......................... 
x0=2;
geometry_RS(1)=makeNURBSarc('disk_arc','center',[x0 -sqrt(2)/2],...
     'angles',[-pi pi/4],'radius',1);
 
Pstart=firstpointNURBSPL(geometry_RS(1));
 
geometry_RS(2)=makeNURBSarc('disk_arc','center',[x0 +sqrt(2)/2],...
     'angles',[-pi/4 pi],'radius',1);
 
P0=lastpointNURBSPL(geometry_RS(2));
P1=[-P0(1) P0(2)];
geometry_RS(3)=makeNURBSarc('segment','vertices',[P0; P1]);

center=P1-[1,0];
geometry_RS(4)=makeNURBSarc('disk_arc','center',center,...
     'angles',[0 pi/4+pi],'radius',1);
 
center=[center(1) -center(2)];
geometry_RS(5)=makeNURBSarc('disk_arc','center',center,...
     'angles',[pi-pi/4 2*pi],'radius',1);
 
P0=lastpointNURBSPL(geometry_RS(5));
P1=Pstart;
geometry_RS(6)=makeNURBSarc('segment','vertices',[P0; P1]);

structure_RS=joinNURBSPLarcs(geometry_RS);




% ....................... Perform hyperinterpolation ......................

[coeff,R,jvec,dbox] = hypRSfit(deg,structure_RS,f);

% ............... Evaluate hyperinterpolant in points in domain ...........
pts=ptsRS(structure_RS,Ngrid); 
in=inRS(pts,structure_RS); iok=find(in == 1); pts0=pts(iok,:);
pval = hypRSval(deg,coeff,pts0,R,jvec,dbox);

% ............................ Test error .................................

fpts=feval(f,pts0(:,1),pts0(:,2));
AE=norm(pval-fpts,inf);
ME=median(abs(pval-fpts));
LA=exp(log(abs(pval-fpts)));

% ............................ Plot figure ................................

h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis equal;

% A. plot domain boundary
plotNURBSPL(structure_RS);

% B. plot test points.

plot(pts0(:,1),pts0(:,2),'g*','MarkerEdgeColor','g',...
    'MarkerFaceColor','g','MarkerSize',2);

hold off;

% ......................... Display statistics ............................
fprintf('\n \t Algebraic Degree of Exactness: %2.0f',deg);
fprintf('\n \t Absolute hyperinterp. error  : %1.3e',AE);
fprintf('\n \t Median hyperinterp. error    : %1.3e',ME);
fprintf('\n \t Log hyperinterp. error       : %1.3e \n',mean(LA));