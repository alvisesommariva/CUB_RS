
function demo_NURBS_cubature_00

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating CUBATURE:
% 1. how to define a NURBS, using arcs of disks, ellipses, segments, 
%    polygons and "free NURBS", i.e. defined directly from control points, 
%    knots, weights and order. The routines work on piecewise NURBS of 
%    different order.
% 2. how to get an algebraic cubature rule on the desired domain, via
%    "cubRS" routine.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------

% ------------------------------ Settings ---------------------------------

% Algebraic degree of precision of the cubature rule. Suggested values are
% mild, e.g. not larger than "ade=15". Typical "ade" in the applications
% are between "3" and "5".
ade=10;


% ----------------------------- Main code ---------------------------------

%--------------------------------------------------------------------------
% 1. Make NURBS structure (define boundary), just knowing 
%
% * control points "P"
% * knots in [0,1]
% * weights
% * order
%
% In this case set the first string as "free", to state that is defined
% without a certain geometric structure of circular, ellptical or polygonal
% type.
%--------------------------------------------------------------------------

geometry_NURBS=makeNURBSarc('free',...
    'P',[0 0; 1 0; 1 1; -2 1; 0 0],...
    'knots',[0 0 0 1/3 2/3 1 1 1],...
    'weights',[1 1 3 2 1],...
    'order',3);


%--------------------------------------------------------------------------
% 2. Compute algebraic cubature rule of the domain (several tests!).
%--------------------------------------------------------------------------
xyw=cubRS(ade,geometry_NURBS);

%--------------------------------------------------------------------------
% 3. Display statistics.
%--------------------------------------------------------------------------
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t          NURBS CUBATURE TESTS \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n');
fprintf('\n \t ALGEBRAIC DEGREE OF PRECISION: %6.0f',ade);
fprintf('\n \t # POINTS                     : %6.0f',size(xyw,1));
w=xyw(:,3); ik=find(w <= 0); NN=length(ik);
fprintf('\n \t NEGATIVE WEIGHTS             : %6.0f',NN);

w=xyw(:,3); condcub=sum(abs(w))/sum(w);
fprintf('\n \t CUBATURE CONDITIONING        : %1.5e \n \n',condcub);
fprintf('\n \t -------------------------------------------');


%--------------------------------------------------------------------------
% 4. Plot domain and control points polygon.
%--------------------------------------------------------------------------
h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis equal;

% Plot boundary

plotNURBSPL(geometry_NURBS); 

% Plot cubature nodes
X=xyw(:,1); Y=xyw(:,2);
plot(X,Y,'go','MarkerEdgeColor','k','MarkerFaceColor','g',...
    'MarkerSize',8); 

% Title
titlesrt=strcat('Algebraic degree of precision:  ',num2str(ade));
title(titlesrt);

hold off;

fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             PLOT DESCRIPTION \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t * Green dots: quadrature nodes.   \n \t');
fprintf('\n \t ------------------------------------------- \n');






