

function demo_nurbs_definedomain_03

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating:
% 1. how to define a NURBS on a composite boundary, using arcs of disks,
%    ellipses, segments, polygons and "free NURBS". The routines work on
%    piecewise NURBS of different order.
%    The result is a vector "geometry_NURBS" of a structure that takes into
%    account control points, knots, weights and orders.
% 2. the application of the "joinNURBSarcs" is important in case the length
%    of the vector "geometry_NURBS" is larger than one, in order to make a
%    "consistent" piecewise NURBS in which knots are well-ordered.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------

% ......................... Design NURBS pieces  ..........................

% add arc of a disk
fprintf('\n \t * Defining arc of a disk');
geometry_NURBS(1)=makeNURBSarc('disk_arc',...
    'center',[0 0],'angles',[0 pi/2],'radius',1);

% add arc of an ellipse
geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
    'center',[0 0],'angles',[pi/2 3*pi/2],'ell_axis',[0.5 1],...
    'tilt_angle',0);

% add a final segment
Pend=lastpointNURBSPL(geometry_NURBS(2));
Pinit=firstpointNURBSPL(geometry_NURBS(1));
geometry_NURBS(3)=makeNURBSarc('segment','vertices',[Pend; Pinit]);

% join pieces
geometry_NURBS=joinNURBSPLarcs(geometry_NURBS);


% ......................... Plot NURBS pieces  ............................
% plot piecewise NURBS curve


h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1);
Nbox=1; % no refining of the boxes
plotNURBSPL(geometry_NURBS,'boxes',Nbox);

h=figure(2);
f2=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f2,clf(2);end
figure(2);
Nbox=10; % refining of the boxes
plotNURBSPL(geometry_NURBS,'boxes',Nbox);
fprintf('\n');


