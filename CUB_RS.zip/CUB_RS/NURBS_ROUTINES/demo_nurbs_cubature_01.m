
function demo_NURBS_cubature_00

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Demo illustrating CUBATURE:
% 1. how to define a NURBS on a composite boundary, using arcs of disks,
%    ellipses, segments, polygons and "free NURBS". The routines work on
%    piecewise NURBS of different order.
%    To this purpose see the MATLAB function "define_domain" at the
%    bottom of this demo.
% 2. how to get an algebraic cubature rule on the desired domain, via
%    "cubRS" routine.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: November 13, 2021;
% Checked: November 16, 2021.
%--------------------------------------------------------------------------

% ------------------------------ Settings ---------------------------------

% Algebraic degree of precision of the cubature rule. Suggested values are
% mild, e.g. not larger than "ade=15". Typical "ade" in the applications
% are between "3" and "5".
ade=10;


% ----------------------------- Main code ---------------------------------

%--------------------------------------------------------------------------
% 1. Make NURBS structure (define boundary), just knowing 
%
% * control points "P"
% * knots in [0,1]
% * weights
% * order
%
% In this case set the first string as "free", to state that is defined
% without a certain geometric structure of circular, ellptical or polygonal
% type.
%--------------------------------------------------------------------------


%--------------------------------------------------------------------------
% 1. Make NURBS structure (define boundary).
%--------------------------------------------------------------------------

% add arc of a disk
geometry_NURBS(1)=makeNURBSarc('disk_arc',...
    'center',[0 0],'angles',[0 pi/2],'radius',1);

% compute first point of the piecewise NURBS domain
Pinit=firstpointNURBSPL(geometry_NURBS(1));

% compute last point of the so made NURBS
Pend=lastpointNURBSPL(geometry_NURBS(end));

% add arc of an ellipse
geometry_NURBS(2)=makeNURBSarc('elliptical_arc',...
    'center',Pend-[1 0],'angles',[0 pi+pi/4],'ell_axis',[1 2],...
    'tilt_angle',0);

% compute last point of the so made NURBS
Pend=lastpointNURBSPL(geometry_NURBS(end));

% add segment
geometry_NURBS(3)=makeNURBSarc('segment','extrema',[Pend; 0 Pend(2)]);

% compute first point of the piecewise NURBS domain
Pinit=firstpointNURBSPL(geometry_NURBS);

% "close" the boundary with a "free" NURBS.
geometry_NURBS(4)=makeNURBSarc('free',...
    'P',[0 Pend(2); -1.9 0.3; -1.8 0.5; Pinit],...
    'knots',[0 0 0 0 1 1 1 1],'weights',[1 1 2 1],'order',4);

% join piecewise NURBS
structure_NURBS=joinNURBSPLarcs(geometry_NURBS);


%--------------------------------------------------------------------------
% 2. Compute algebraic cubature rule of the domain (several tests!).
%--------------------------------------------------------------------------
xyw=cubRS(ade,structure_NURBS);

%--------------------------------------------------------------------------
% 3. Display statistics.
%--------------------------------------------------------------------------
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t          NURBS CUBATURE TESTS \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n');
fprintf('\n \t ALGEBRAIC DEGREE OF PRECISION: %6.0f',ade);
fprintf('\n \t # POINTS                     : %6.0f',size(xyw,1));
w=xyw(:,3); ik=find(w <= 0); NN=length(ik);
fprintf('\n \t NEGATIVE WEIGHTS             : %6.0f',NN);

w=xyw(:,3); condcub=sum(abs(w))/sum(w);
fprintf('\n \t CUBATURE CONDITIONING        : %1.3e \n \n',condcub);
fprintf('\n \t ------------------------------------------- ');


%--------------------------------------------------------------------------
% 4. Plot domain and control points polygon.
%--------------------------------------------------------------------------
h=figure(1);
f1=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f1,clf(1);end
figure(1)
hold on;
axis equal;

% Plot boundary

plotNURBSPL(structure_NURBS); 

% Plot cubature nodes
X=xyw(:,1); Y=xyw(:,2);
plot(X,Y,'go','MarkerEdgeColor','k','MarkerFaceColor','g',...
    'MarkerSize',8); 

% Title
titlesrt=strcat('Algebraic degree of precision:  ',num2str(ade));
title(titlesrt);

hold off;

fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t             PLOT DESCRIPTION \n \t');
fprintf('\n \t ------------------------------------------- \n \t');
fprintf('\n \t * Green dots: quadrature nodes.   \n \t');
fprintf('\n \t ------------------------------------------- \n');






